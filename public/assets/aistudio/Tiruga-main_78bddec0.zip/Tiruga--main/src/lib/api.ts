/**
 * Client API helper for interacting with the Express backend.
 */

export interface HealthResponse {
  ok: boolean;
  time?: string;
  error?: {
    code: string;
    message: string;
  };
}

/**
 * Pings GET /api/health to verify client-to-server connectivity.
 */
export async function getHealth(): Promise<HealthResponse> {
  try {
    const response = await fetch('/api/health');
    if (!response.ok) {
      return {
        ok: false,
        error: {
          code: `HTTP_${response.status}`,
          message: `Server returned status ${response.status}`
        }
      };
    }
    const data = await response.json();
    return data;
  } catch (err: any) {
    return {
      ok: false,
      error: {
        code: 'NETWORK_ERROR',
        message: err.message || 'Unable to connect to server'
      }
    };
  }
}
