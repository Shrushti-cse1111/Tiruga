import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { testConnection } from './lib/firebase';

// Validate connection to Firestore on boot as mandated by Firebase integration guidelines
testConnection();

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    try {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('SW registration failed:', err);
      });
    } catch (err) {
      console.warn('SW registration error:', err);
    }
  });
}

createRoot(document.getElementById('root')!).render(<App />);
