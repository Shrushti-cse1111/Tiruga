import destinationsData from '../../data/destinations.json';

export interface Destination {
  id: string;
  name: string;
  nameKn?: string;
  kannadaName: string;
  district: string;
  categories: ('Heritage' | 'Nature' | 'Food' | 'Adventure' | 'Beaches' | 'Culture')[];
  description: string;
  image: string;
  recommendedDays: number;
  budgetLevel: 'Under ₹3,000' | '₹3,000 - ₹5,000' | '₹5,000 - ₹10,000' | '₹10,000+';
  highlights: string[];
  tags?: string[];
  bestSeason?: string;
  familySuitable?: boolean;
  studentSuitable?: boolean;
  foodHighlights?: string[];
}

export const SEED_DESTINATIONS: Destination[] = destinationsData as Destination[];

export async function getDestinations(): Promise<Destination[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([...SEED_DESTINATIONS]);
    }, 120);
  });
}
