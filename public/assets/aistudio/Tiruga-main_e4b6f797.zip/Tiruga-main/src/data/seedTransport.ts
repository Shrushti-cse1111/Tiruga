import transportData from '../../data/transport.json';
import { TransportOption } from './types';

export const SEED_TRANSPORT_OPTIONS: TransportOption[] = transportData as unknown as TransportOption[];

/**
 * Loads transport options for a given route and date.
 * TODO: replace with server call / official transport aggregator API
 */
export async function getTransport(
  from: string = 'Bengaluru',
  to: string = 'Hampi',
  travelDate?: string
): Promise<TransportOption[]> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([...SEED_TRANSPORT_OPTIONS]);
    }, 120);
  });
}
