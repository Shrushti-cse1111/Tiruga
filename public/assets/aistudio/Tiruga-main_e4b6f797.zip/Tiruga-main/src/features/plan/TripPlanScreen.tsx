import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  SlidersHorizontal,
  Clock,
  Wallet,
  Sparkles,
  Calendar,
  Landmark,
  Utensils,
  Mountain,
  Camera,
  MapPin,
  Car,
  Bookmark,
  Download,
  Share2,
  HelpCircle,
  Check,
  X,
  ChevronRight,
  AlertTriangle,
  Umbrella,
  Bus
} from 'lucide-react';
import { Trip, Day, TripItem } from '../../data/types';
import { getTrip, modifyTrip, askAboutPlace } from '../../data/seedTrip';
import { useOnlineStatus } from '../../lib/useOnlineStatus';
import { getOfflineTrip } from '../../lib/offlineStore';
import { useAuth } from '../../lib/auth';
import { saveTrip } from '../../lib/db';
import demoTripJson from '../../../data/demoTrip.json';
import { AskAboutPlaceSheet } from '../../components/common/AskAboutPlaceSheet';
import {
  ImageWithFallback,
  Button,
  Card,
  Chip,
  LoadingSkeleton,
  EmptyState,
  BottomNav
} from '../../components/common/CommonComponents';

export const TripPlanScreen: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isOnline = useOnlineStatus();
  const [askPlaceName, setAskPlaceName] = useState<string | null>(null);

  const { user } = useAuth();
  const isDemoParam = new URLSearchParams(window.location.search).get('demo') === '1';

  // State
  const [trip, setTrip] = useState<Trip | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeDayIndex, setActiveDayIndex] = useState<number>(0);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Offline download simulation
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [isDownloaded, setIsDownloaded] = useState<boolean>(false);

  // Bottom sheets
  const [isFullItineraryOpen, setIsFullItineraryOpen] = useState<boolean>(false);
  const [isModifySheetOpen, setIsModifySheetOpen] = useState<boolean>(false);
  const [isCheaperSheetOpen, setIsCheaperSheetOpen] = useState<boolean>(false);
  const [modifyPrompt, setModifyPrompt] = useState<string>('');
  const [isModifying, setIsModifying] = useState<boolean>(false);
  const [modifiedPreview, setModifiedPreview] = useState<Trip | null>(null);

  // Ask about place sheet
  const [activePlaceQuestion, setActivePlaceQuestion] = useState<{
    place: TripItem;
    isOpen: boolean;
  } | null>(null);
  const [placeQuery, setPlaceQuery] = useState<string>('');
  const [placeAnswer, setPlaceAnswer] = useState<{
    answer: string;
    confidence: number;
    source: string;
  } | null>(null);
  const [isAskingPlace, setIsAskingPlace] = useState<boolean>(false);

  // Load trip on mount or id change
  useEffect(() => {
    let mounted = true;
    setIsLoading(true);
    setError(null);

    const loadData = async () => {
      try {
        if (!isOnline) {
          const offlineData = await getOfflineTrip(id || 'trip_hampi_3d');
          if (offlineData && mounted) {
            setTrip(offlineData);
            setIsLoading(false);
            return;
          }
        }
        const data = await getTrip(id || 'trip_hampi_3d');
        if (mounted) {
          setTrip(data);
          setIsLoading(false);
        }
      } catch (err: any) {
        if (mounted) {
          const offlineData = await getOfflineTrip(id || 'trip_hampi_3d');
          if (offlineData) {
            setTrip(offlineData);
          } else {
            setError(err.message || 'Failed to load trip itinerary.');
          }
          setIsLoading(false);
        }
      }
    };

    loadData();

    return () => {
      mounted = false;
    };
  }, [id, isOnline]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveToggle = async () => {
    const next = !isSaved;
    setIsSaved(next);
    if (trip) {
      try {
        await saveTrip(trip, user?.uid);
        showToast(next ? 'Trip saved to your profile' : 'Trip removed from saved');
      } catch {
        showToast(next ? 'Trip saved locally' : 'Trip removed from saved');
      }
    }
  };

  const handleUseBackup = () => {
    const backup = demoTripJson as unknown as Trip;
    setTrip(backup);
    setError(null);
    showToast('Loaded 3-day Hampi backup itinerary');
  };

  const handleApplyCheaper = async () => {
    if (!trip) return;
    const optimizedBudget = 4200;
    const updatedDays = trip.days.map((day) => ({
      ...day,
      summary: `${day.summary} (Budget-Optimized)`,
      items: day.items.map((item) => ({
        ...item,
        estimatedCost: Math.min(item.estimatedCost, 120),
        reason: `${item.reason} Optimized with local State Sarige and thali dining.`
      }))
    }));

    const updatedTrip: Trip = {
      ...trip,
      estimatedBudget: optimizedBudget,
      days: updatedDays,
      tags: Array.from(new Set([...(trip.tags || []), 'Budget-Optimized']))
    };

    setTrip(updatedTrip);
    setIsCheaperSheetOpen(false);
    try {
      await saveTrip(updatedTrip, user?.uid);
    } catch {}
    showToast(`Applied savings! New estimated total: ₹${optimizedBudget}`);
  };

  const handleDownload = () => {
    if (isDownloaded || isDownloading) return;
    setIsDownloading(true);
    setDownloadProgress(20);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsDownloading(false);
          setIsDownloaded(true);
          showToast('Itinerary and offline maps cached!');
          return 100;
        }
        return prev + 30;
      });
    }, 250);
  };

  // Modify with AI
  const handleRunModify = async (instruction: string) => {
    if (!trip || !instruction.trim()) return;
    setIsModifying(true);
    try {
      const updated = await modifyTrip(trip.id, instruction);
      setModifiedPreview(updated);
    } catch (err: any) {
      showToast(err.message || 'Failed to modify trip.');
    } finally {
      setIsModifying(false);
    }
  };

  const handleApplyModification = async () => {
    if (modifiedPreview) {
      const updated = modifiedPreview;
      setTrip(updated);
      setModifiedPreview(null);
      setIsModifySheetOpen(false);
      try {
        await saveTrip(updated, user?.uid);
      } catch {}
      showToast('Trip itinerary updated successfully!');
    }
  };

  // Ask about place
  const handleAskPlace = async (item: TripItem, query: string) => {
    setIsAskingPlace(true);
    setPlaceQuery(query);
    try {
      const res = await askAboutPlace(item.title, query);
      setPlaceAnswer(res);
    } catch {
      setPlaceAnswer({
        answer: 'Information temporarily unavailable. Please check official ASI counters.',
        confidence: 0.5,
        source: 'Fallback guide'
      });
    } finally {
      setIsAskingPlace(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'temple':
        return <Landmark size={18} className="text-terracotta" />;
      case 'heritage':
        return <Landmark size={18} className="text-primary-teal" />;
      case 'food':
        return <Utensils size={18} className="text-gold" />;
      case 'nature':
      case 'viewpoint':
        return <Mountain size={18} className="text-primary-teal" />;
      default:
        return <Camera size={18} className="text-primary-teal" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-cream flex flex-col justify-between max-w-[430px] mx-auto p-4 space-y-4">
        <LoadingSkeleton count={3} />
      </div>
    );
  }

  if (error || !trip) {
    return (
      <div className="min-h-screen bg-cream flex flex-col items-center justify-center p-6 max-w-[430px] mx-auto">
        <EmptyState
          title="Trip Not Found"
          subtitle={error || "We couldn't locate the requested Karnataka itinerary."}
          actionText="Go to Home"
          onAction={() => navigate('/home')}
        />
      </div>
    );
  }

  const currentDay = trip.days[activeDayIndex] || trip.days[0];
  const dayTotalCost = currentDay.items.reduce((sum, item) => sum + item.estimatedCost, 0);

  return (
    <div className="min-h-screen bg-cream text-text-main flex flex-col justify-between max-w-[430px] mx-auto pb-6 relative select-none">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-deep-teal text-white px-4 py-2.5 rounded-full shadow-lg text-xs font-medium flex items-center space-x-2 animate-fade-in border border-white/20">
          <Check size={14} className="text-gold" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1">
        {/* 1. Hero Destination Image */}
        <div className="relative rounded-b-[32px] overflow-hidden shadow-md">
          <ImageWithFallback
            src={trip.heroImage}
            alt={trip.destination}
            aspectRatio="aspect-[16/10]"
            fallbackTitle={trip.destination}
            className="w-full h-full object-cover"
          />
          {/* Deep Teal Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-deep-teal via-deep-teal/40 to-transparent flex flex-col justify-between p-4 sm:p-5">
            {/* Top Bar Navigation */}
            <div className="flex items-center justify-between z-10">
              <button
                type="button"
                onClick={() => navigate('/home')}
                aria-label="Back to home"
                className="w-11 h-11 rounded-full bg-deep-teal/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-deep-teal transition-colors border border-white/20 cursor-pointer"
              >
                <ArrowLeft size={20} />
              </button>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handleSaveToggle}
                  aria-label="Save trip"
                  className={`w-11 h-11 rounded-full backdrop-blur-md flex items-center justify-center border transition-colors cursor-pointer ${
                    isSaved
                      ? 'bg-gold text-deep-teal border-gold'
                      : 'bg-deep-teal/60 text-white border-white/20 hover:bg-deep-teal'
                  }`}
                >
                  <Bookmark size={18} fill={isSaved ? '#103F38' : 'none'} />
                </button>
                <button
                  type="button"
                  onClick={() => setIsModifySheetOpen(true)}
                  aria-label="Modify trip with AI"
                  className="w-11 h-11 rounded-full bg-deep-teal/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-deep-teal transition-colors border border-white/20 cursor-pointer"
                >
                  <SlidersHorizontal size={18} />
                </button>
              </div>
            </div>

            {/* Bottom Hero Info */}
            <div className="text-white z-10">
              {/* Badge */}
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-xs font-semibold text-white">
                  <span>
                    {trip.totalDays} Days · ₹{trip.estimatedBudget.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] opacity-80 ml-1.5 font-normal">(Estimated)</span>
                </div>
                <span className="bg-gold text-deep-teal font-extrabold text-[10px] px-2.5 py-1 rounded-full inline-flex items-center gap-1 shadow-xs">
                  <Sparkles size={11} className="fill-deep-teal" /> AI-generated
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight font-heading leading-tight">
                {trip.destination}
              </h1>
              <p className="text-xs sm:text-sm text-white/90 mt-1 font-medium">
                {(trip.tags || ['Heritage', 'Adventure', 'Culture']).join(' · ')}
              </p>
            </div>
          </div>
        </div>

        {/* Padding Container for Body */}
        <div className="px-4 py-4 space-y-5">
          {/* 2. Summary Row (Three equal mini-cards) */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-white p-3 rounded-2xl border border-[#E2DFD3] shadow-xs flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-mint flex items-center justify-center text-deep-teal mb-1">
                <Calendar size={16} />
              </div>
              <span className="text-xs font-bold text-text-main">{trip.totalDays} Days</span>
              <span className="text-[10px] text-muted-text mt-0.5">Duration</span>
            </div>

            <div className="bg-white p-3 rounded-2xl border border-[#E2DFD3] shadow-xs flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-mint flex items-center justify-center text-deep-teal mb-1">
                <Wallet size={16} />
              </div>
              <span className="text-xs font-bold text-text-main">
                ₹{trip.estimatedBudget.toLocaleString('en-IN')}
              </span>
              <span className="text-[10px] text-muted-text mt-0.5">Estimated</span>
            </div>

            <div className="bg-white p-3 rounded-2xl border border-[#E2DFD3] shadow-xs flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-mint flex items-center justify-center text-deep-teal mb-1">
                <Sparkles size={16} className="text-gold" />
              </div>
              <span className="text-xs font-bold text-text-main truncate max-w-full">
                {trip.travelStyle}
              </span>
              <span className="text-[10px] text-muted-text mt-0.5">Style</span>
            </div>
          </div>

          {/* Quick Access Action Banners (Travel Options & Plan B) */}
          <div className="grid grid-cols-2 gap-2.5">
            <Link
              to="/travel-options"
              className="bg-white p-3 rounded-2xl border border-[#E2DFD3] shadow-xs flex items-center justify-between hover:border-primary-teal transition-colors group cursor-pointer"
            >
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-mint text-deep-teal flex items-center justify-center">
                  <Bus size={16} />
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold text-text-main group-hover:text-primary-teal transition-colors">
                    Travel Options
                  </div>
                  <div className="text-[10px] text-muted-text">Buses, Trains, Cabs</div>
                </div>
              </div>
              <ChevronRight size={14} className="text-muted-text" />
            </Link>

            <Link
              to="/plan-b"
              className="bg-white p-3 rounded-2xl border border-terracotta/30 bg-terracotta/5 shadow-xs flex items-center justify-between hover:border-terracotta transition-colors group cursor-pointer"
            >
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-terracotta/15 text-terracotta flex items-center justify-center">
                  <Umbrella size={16} />
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold text-text-main group-hover:text-terracotta transition-colors">
                    Plan B & Weather
                  </div>
                  <div className="text-[10px] text-muted-text">Rain & Heat Adapt</div>
                </div>
              </div>
              <ChevronRight size={14} className="text-terracotta" />
            </Link>
          </div>

          {/* 3. Day Tabs (Pill segmented tabs) */}
          <div className="flex space-x-2 overflow-x-auto pb-1 no-scrollbar">
            {trip.days.map((d, idx) => {
              const isActive = idx === activeDayIndex;
              return (
                <button
                  key={d.dayNumber}
                  type="button"
                  onClick={() => setActiveDayIndex(idx)}
                  className={`min-h-[44px] px-5 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-deep-teal text-white shadow-sm'
                      : 'bg-white text-muted-text border border-[#E2DFD3] hover:text-text-main'
                  }`}
                >
                  Day {d.dayNumber}
                </button>
              );
            })}
          </div>

          {/* 4. Day Header */}
          <div className="bg-white/80 backdrop-blur-xs p-4 rounded-2xl border border-[#E2DFD3]">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-text-main">
                Day {currentDay.dayNumber} – {trip.destination}
              </h2>
              <span className="text-xs font-bold text-primary-teal bg-mint px-2.5 py-1 rounded-full">
                ₹{dayTotalCost} est.
              </span>
            </div>
            <p className="text-xs text-muted-text mt-1 leading-relaxed">{currentDay.summary}</p>
          </div>

          {/* 5. Vertical Timeline */}
          <div className="relative pl-6 space-y-5 before:absolute before:left-[17px] before:top-3 before:bottom-3 before:w-0.5 before:bg-[#E2DFD3]">
            {currentDay.items.map((item, index) => {
              return (
                <div key={item.attractionId + index} className="relative group">
                  {/* Circular Node */}
                  <div className="absolute -left-[23px] top-1.5 w-8 h-8 rounded-full bg-white border-2 border-primary-teal shadow-xs flex items-center justify-center z-10">
                    {getCategoryIcon(item.category)}
                  </div>

                  {/* Timeline Card */}
                  <div className="bg-white p-4 rounded-2xl border border-[#E2DFD3] shadow-xs hover:border-primary-teal/40 transition-all">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-bold text-primary-teal font-mono">
                            {item.time}
                          </span>
                          <span className="text-[11px] text-muted-text flex items-center">
                            <Clock size={12} className="mr-1" />
                            {item.durationMinutes} min
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-text-main mt-1">{item.title}</h3>
                      </div>

                      {/* Cost chip */}
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                          item.estimatedCost === 0
                            ? 'bg-mint text-deep-teal'
                            : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {item.estimatedCost === 0 ? 'Free' : `₹${item.estimatedCost}`}
                      </span>
                    </div>

                    {/* Why this was picked */}
                    <p className="text-xs text-muted-text mt-2 leading-relaxed bg-cream/70 p-2 rounded-xl">
                      <span className="font-semibold text-text-main">Why picked: </span>
                      {item.reason}
                    </p>

                    {/* Small Reason Chips */}
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      {item.tags.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[10px] font-medium bg-[#F0ECE1] text-text-main px-2 py-0.5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}

                      {/* Ask about this place link */}
                      <button
                        type="button"
                        onClick={() => {
                          if (!isOnline) {
                            showToast('AI features need an internet connection.');
                            return;
                          }
                          setAskPlaceName(item.title);
                        }}
                        className={`text-[10px] font-semibold flex items-center ml-auto cursor-pointer ${
                          !isOnline ? 'text-muted-text opacity-50' : 'text-primary-teal hover:underline'
                        }`}
                        title={!isOnline ? 'AI features need an internet connection.' : undefined}
                      >
                        <HelpCircle size={12} className="mr-1" />
                        Ask about this place
                      </button>
                    </div>
                  </div>

                  {/* Travel Time to Next Item */}
                  {item.travelToNextMinutes && (
                    <div className="flex items-center space-x-2 py-2 text-[11px] text-muted-text font-medium">
                      <Car size={13} className="text-primary-teal ml-1" />
                      <span>~{item.travelToNextMinutes} min auto / walk to next spot</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* 6. Action Area */}
          <div className="space-y-3 pt-3">
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="white"
                size="md"
                className="w-full text-xs"
                onClick={() => setIsFullItineraryOpen(true)}
              >
                View Full Itinerary
              </Button>

              <Button
                variant="primary"
                size="md"
                className={`w-full text-xs ${!isOnline ? 'opacity-50' : ''}`}
                disabled={!isOnline}
                onClick={() => {
                  if (!isOnline) {
                    showToast('AI features need an internet connection.');
                    return;
                  }
                  setIsModifySheetOpen(true);
                }}
                title={!isOnline ? 'AI features need an internet connection.' : undefined}
              >
                <Sparkles size={14} className="mr-1.5 text-gold" />
                Modify with AI
              </Button>
            </div>

            {/* Make it Cheaper (Budget Optimizer) Button */}
            <Button
              variant="white"
              size="md"
              className="w-full text-xs border border-primary-teal text-primary-teal hover:bg-mint/30 font-bold flex items-center justify-center cursor-pointer"
              onClick={() => setIsCheaperSheetOpen(true)}
            >
              <Wallet size={14} className="mr-1.5 text-primary-teal" />
              Make it cheaper (Budget Optimizer)
            </Button>

            {/* Offline Download Button */}
            <button
              type="button"
              onClick={handleDownload}
              disabled={isDownloaded || isDownloading}
              className={`w-full min-h-[48px] rounded-full border px-4 py-2.5 text-xs font-bold flex items-center justify-center transition-all cursor-pointer ${
                isDownloaded
                  ? 'bg-mint text-deep-teal border-primary-teal/30'
                  : 'bg-white text-text-main border-[#E2DFD3] hover:border-primary-teal'
              }`}
            >
              {isDownloading ? (
                <div className="w-full flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 border-2 border-deep-teal border-t-transparent rounded-full animate-spin" />
                  <span>Downloading offline maps ({downloadProgress}%)...</span>
                </div>
              ) : isDownloaded ? (
                <div className="flex items-center space-x-1.5">
                  <Check size={16} className="text-deep-teal" />
                  <span>Downloaded for Offline Use ✓</span>
                </div>
              ) : (
                <div className="flex items-center space-x-1.5">
                  <Download size={15} />
                  <span>Download for Offline Use</span>
                </div>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 7. Bottom Navigation */}
      <BottomNav />

      {/* Bottom Sheet: Full Itinerary */}
      {isFullItineraryOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs animate-fade-in p-0 sm:p-4">
          <div className="bg-white w-full max-w-[430px] rounded-t-[32px] sm:rounded-[32px] max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-[#E2DFD3]">
            <div className="p-4 border-b border-[#E2DFD3] flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-text-main">Full Karnataka Itinerary</h3>
                <p className="text-xs text-muted-text">
                  {trip.title} · {trip.totalDays} Days
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsFullItineraryOpen(false)}
                className="w-9 h-9 rounded-full bg-cream flex items-center justify-center text-text-main hover:bg-[#E2DFD3] cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 no-scrollbar">
              {trip.days.map((day) => (
                <div
                  key={day.dayNumber}
                  className="bg-cream/60 p-4 rounded-2xl border border-[#E2DFD3]"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-primary-teal uppercase tracking-wider">
                      Day {day.dayNumber}
                    </span>
                    <span className="text-xs font-medium text-muted-text">
                      ₹{day.items.reduce((acc, i) => acc + i.estimatedCost, 0)} total
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-text-main mb-2">{day.summary}</h4>
                  <ul className="space-y-2 text-xs">
                    {day.items.map((item, iIdx) => (
                      <li key={iIdx} className="flex items-start justify-between py-1">
                        <div>
                          <span className="font-mono font-bold text-primary-teal mr-2">
                            {item.time}
                          </span>
                          <span className="font-semibold text-text-main">{item.title}</span>
                          <p className="text-[11px] text-muted-text ml-14">{item.reason}</p>
                        </div>
                        <span className="text-[11px] font-bold text-muted-text whitespace-nowrap ml-2">
                          {item.estimatedCost === 0 ? 'Free' : `₹${item.estimatedCost}`}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-[#E2DFD3] bg-white">
              <Button
                variant="primary"
                fullWidth
                size="md"
                onClick={() => {
                  setIsFullItineraryOpen(false);
                  showToast('Itinerary ready for printing / sharing');
                }}
              >
                <Share2 size={16} className="mr-2" />
                Share or Print Itinerary
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Sheet: Modify with AI */}
      {isModifySheetOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs animate-fade-in p-0 sm:p-4">
          <div className="bg-white w-full max-w-[430px] rounded-t-[32px] sm:rounded-[32px] max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-[#E2DFD3]">
            <div className="p-4 border-b border-[#E2DFD3] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-mint text-deep-teal flex items-center justify-center">
                  <Sparkles size={16} className="text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-text-main">Modify Trip with AI</h3>
                  <p className="text-xs text-muted-text">Adaptive Karnataka itinerary customization</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsModifySheetOpen(false);
                  setModifiedPreview(null);
                }}
                className="w-9 h-9 rounded-full bg-cream flex items-center justify-center text-text-main hover:bg-[#E2DFD3] cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 no-scrollbar">
              {/* Presets */}
              <div>
                <label className="text-xs font-bold text-text-main block mb-2">
                  Quick AI Presets
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Make it more relaxed',
                    'Focus on food & cafés',
                    'Budget under Rs 4,000'
                  ].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => {
                        setModifyPrompt(preset);
                        handleRunModify(preset);
                      }}
                      className="text-xs bg-cream hover:bg-mint hover:text-deep-teal text-text-main font-semibold px-3 py-2 rounded-full border border-[#E2DFD3] transition-colors cursor-pointer"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Input */}
              <div>
                <label className="text-xs font-bold text-text-main block mb-1.5">
                  Or enter your own request
                </label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={modifyPrompt}
                    onChange={(e) => setModifyPrompt(e.target.value)}
                    placeholder="e.g. Add more sunset points, skip steep climbs..."
                    className="flex-1 bg-cream border border-[#E2DFD3] rounded-2xl px-3.5 py-2.5 text-xs text-text-main placeholder:text-muted-text focus:outline-primary-teal"
                  />
                  <Button
                    variant="primary"
                    size="sm"
                    disabled={isModifying || !modifyPrompt.trim()}
                    onClick={() => handleRunModify(modifyPrompt)}
                  >
                    {isModifying ? 'Adapting...' : 'Run'}
                  </Button>
                </div>
              </div>

              {/* Preview of changes */}
              {modifiedPreview && (
                <div className="bg-mint/40 border border-primary-teal/40 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-deep-teal">Preview of Modified Day 1</span>
                    <span className="text-[10px] bg-primary-teal text-white px-2 py-0.5 rounded-full font-bold">
                      ₹{modifiedPreview.estimatedBudget} total est.
                    </span>
                  </div>
                  <p className="text-xs font-medium text-text-main">{modifiedPreview.days[0].summary}</p>
                  <div className="space-y-1.5 pt-1 text-xs">
                    {modifiedPreview.days[0].items.map((mItem, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-white/80 p-2 rounded-xl">
                        <span className="font-semibold">{mItem.title}</span>
                        <span className="text-muted-text font-mono text-[11px]">{mItem.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-[#E2DFD3] bg-white flex space-x-3">
              <Button
                variant="ghost"
                className="flex-1 text-xs"
                onClick={() => {
                  setIsModifySheetOpen(false);
                  setModifiedPreview(null);
                }}
              >
                Discard
              </Button>
              <Button
                variant="primary"
                className="flex-1 text-xs"
                disabled={!modifiedPreview}
                onClick={handleApplyModification}
              >
                Apply Changes
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Bottom Sheet: Make it Cheaper (Budget Optimizer) */}
      {isCheaperSheetOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-xs animate-fade-in p-0 sm:p-4">
          <div className="bg-white w-full max-w-[430px] rounded-t-[32px] sm:rounded-[32px] max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-[#E2DFD3]">
            {/* Header */}
            <div className="p-4 border-b border-[#E2DFD3] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-full bg-mint text-deep-teal flex items-center justify-center">
                  <Wallet size={16} />
                </div>
                <div>
                  <h3 className="font-bold text-base text-text-main">Make it Cheaper</h3>
                  <p className="text-xs text-muted-text">AI Budget Optimizer for Karnataka travel</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCheaperSheetOpen(false)}
                className="w-9 h-9 rounded-full bg-cream flex items-center justify-center text-text-main hover:bg-[#E2DFD3] cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Content */}
            <div className="p-4 overflow-y-auto space-y-4 no-scrollbar">
              {/* Before / After Comparison Card */}
              <div className="bg-cream/80 border border-[#E2DFD3] rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-muted-text">
                  <span>Current Estimate</span>
                  <span>Optimized Budget</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xl font-extrabold text-muted-text line-through">
                    ₹{trip.estimatedBudget.toLocaleString('en-IN')}
                  </span>
                  <div className="text-right">
                    <span className="text-2xl font-black text-deep-teal">₹4,200</span>
                    <span className="text-[10px] text-muted-text block">Estimated</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#E2DFD3] flex items-center justify-between">
                  <span className="text-xs font-bold text-deep-teal">Projected Savings:</span>
                  <span className="text-xs font-extrabold bg-mint text-deep-teal px-2 py-0.5 rounded-full">
                    Save ₹{Math.max(0, trip.estimatedBudget - 4200).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Savings Breakdown List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-text-main uppercase tracking-wider">
                  Recommended Optimizations
                </h4>
                <div className="space-y-2">
                  <div className="bg-white border border-[#E2DFD3] p-3 rounded-xl flex items-start justify-between">
                    <div>
                      <div className="text-xs font-bold text-text-main">
                        KSRTC Sarige & Walkable Routes
                      </div>
                      <div className="text-[11px] text-muted-text mt-0.5">
                        Replace individual auto rides with local state bus lines and riverside walking clusters.
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-deep-teal ml-2 whitespace-nowrap bg-mint px-2 py-0.5 rounded-full">
                      -₹1,200
                    </span>
                  </div>

                  <div className="bg-white border border-[#E2DFD3] p-3 rounded-xl flex items-start justify-between">
                    <div>
                      <div className="text-xs font-bold text-text-main">
                        Traditional Khanavali Thali Dining
                      </div>
                      <div className="text-[11px] text-muted-text mt-0.5">
                        Savor unlimited North Karnataka Jolada Rotti meals at local eateries over tourist cafes.
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-deep-teal ml-2 whitespace-nowrap bg-mint px-2 py-0.5 rounded-full">
                      -₹800
                    </span>
                  </div>

                  <div className="bg-white border border-[#E2DFD3] p-3 rounded-xl flex items-start justify-between">
                    <div>
                      <div className="text-xs font-bold text-text-main">
                        ASI Pass & Free Morning Ghats
                      </div>
                      <div className="text-[11px] text-muted-text mt-0.5">
                        Utilize single-entry composite heritage passes and free sunrise boulders.
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-deep-teal ml-2 whitespace-nowrap bg-mint px-2 py-0.5 rounded-full">
                      -₹800
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="p-4 border-t border-[#E2DFD3] bg-white flex space-x-3">
              <Button
                variant="ghost"
                className="flex-1 text-xs"
                onClick={() => setIsCheaperSheetOpen(false)}
              >
                Keep Current
              </Button>
              <Button
                variant="primary"
                className="flex-1 text-xs bg-deep-teal text-white font-bold"
                onClick={handleApplyCheaper}
              >
                Apply Savings
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Culture Guide: Reusable AskAboutPlaceSheet */}
      <AskAboutPlaceSheet
        placeName={askPlaceName || ''}
        isOpen={!!askPlaceName}
        onClose={() => setAskPlaceName(null)}
      />
    </div>
  );
};
