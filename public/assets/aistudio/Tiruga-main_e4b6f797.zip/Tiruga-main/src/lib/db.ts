import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './firebase';
import destinationsJson from '../../data/destinations.json';
import attractionsJson from '../../data/attractions.json';
import phrasesJson from '../../data/phrases.json';
import transportJson from '../../data/transport.json';
import { Attraction, TransportOption, Trip } from '../data/types';
import { Destination } from '../data/seedDestinations';
import { KannadaPhrase } from '../data/seedPhrases';

export interface DestinationItem extends Destination {
  nameKn: string;
  tags: string[];
  bestSeason: string;
  familySuitable: boolean;
  studentSuitable: boolean;
  foodHighlights: string[];
}

export interface AttractionItem extends Attraction {
  destinationId: string;
  durationMinutes: number;
  estimatedCost: number;
  indoor: boolean;
  lat: number;
  lng: number;
  mapX: number;
  mapY: number;
}

export interface TransportItem extends TransportOption {
  type: 'bus' | 'train' | 'cab';
  from: string;
  to: string;
  departure: string;
  durationMinutes: number;
  stops: number;
  priceEstimate: number;
}

const STORAGE_SAVED_TRIPS_KEY = 'tiruga_saved_trips';
const STORAGE_SAVED_PLACES_KEY = 'tiruga_saved_places';

// In-Memory Caches (Session-scoped)
const destinationsCache = new Map<string, DestinationItem[]>();
const attractionsCache = new Map<string, AttractionItem[]>();
let phrasesCache: KannadaPhrase[] | null = null;
let transportCache: TransportOption[] | null = null;

/**
 * 1. Get Destinations Catalog
 * Uses in-memory cache -> localStorage -> Firestore getDocs -> local JSON fallback.
 */
export async function getDestinations(): Promise<DestinationItem[]> {
  if (destinationsCache.has('all')) {
    return destinationsCache.get('all')!;
  }

  // Check localStorage cache
  try {
    const cached = localStorage.getItem('tiruga_destinations_v1');
    if (cached) {
      const parsed = JSON.parse(cached) as DestinationItem[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        destinationsCache.set('all', parsed);
        return parsed;
      }
    }
  } catch (e) {
    console.warn('LocalStorage destinations cache notice:', e);
  }

  // Try Firestore getDocs
  try {
    const snap = await getDocs(collection(db, 'destinations'));
    if (!snap.empty) {
      const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as DestinationItem));
      destinationsCache.set('all', items);
      try {
        localStorage.setItem('tiruga_destinations_v1', JSON.stringify(items));
      } catch {}
      return items;
    }
  } catch (err) {
    console.warn('Firestore getDestinations fallback active:', err);
  }

  // Fallback to local JSON
  const fallback = destinationsJson as DestinationItem[];
  destinationsCache.set('all', fallback);
  return fallback;
}

/**
 * 2. Get Attractions Catalog for a destination
 * Reads subcollection destinations/{destinationId}/attractions with local JSON fallback.
 */
export async function getAttractions(destinationId: string = 'hampi'): Promise<AttractionItem[]> {
  const normId = destinationId.trim().toLowerCase();
  if (attractionsCache.has(normId)) {
    return attractionsCache.get(normId)!;
  }

  // Check localStorage cache
  try {
    const cached = localStorage.getItem(`tiruga_attractions_${normId}_v1`);
    if (cached) {
      const parsed = JSON.parse(cached) as AttractionItem[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        attractionsCache.set(normId, parsed);
        return parsed;
      }
    }
  } catch {}

  // Try Firestore subcollection getDocs
  try {
    const subColRef = collection(db, 'destinations', normId, 'attractions');
    const snap = await getDocs(subColRef);
    if (!snap.empty) {
      const items = snap.docs.map((d) => ({
        id: d.id,
        destinationId: normId,
        ...d.data()
      } as AttractionItem));
      attractionsCache.set(normId, items);
      try {
        localStorage.setItem(`tiruga_attractions_${normId}_v1`, JSON.stringify(items));
      } catch {}
      return items;
    }
  } catch (err) {
    console.warn(`Firestore getAttractions fallback for ${normId}:`, err);
  }

  // Fallback to local JSON
  const allAttractions = attractionsJson as AttractionItem[];
  const filtered = allAttractions.filter(
    (att) => att.destinationId.toLowerCase() === normId || att.destinationId.toLowerCase().includes(normId)
  );
  const result = filtered.length > 0 ? filtered : allAttractions.slice(0, 10);
  attractionsCache.set(normId, result);
  return result;
}

/**
 * 3. Get Kannada Phrases
 * Fetches all phrases once and caches them.
 */
export async function getPhrases(category?: string): Promise<KannadaPhrase[]> {
  if (!phrasesCache) {
    try {
      const cached = localStorage.getItem('tiruga_phrases_v1');
      if (cached) {
        phrasesCache = JSON.parse(cached);
      }
    } catch {}

    if (!phrasesCache) {
      try {
        const snap = await getDocs(collection(db, 'phrases'));
        if (!snap.empty) {
          phrasesCache = snap.docs.map((d) => ({ id: d.id, ...d.data() } as KannadaPhrase));
          try {
            localStorage.setItem('tiruga_phrases_v1', JSON.stringify(phrasesCache));
          } catch {}
        }
      } catch (err) {
        console.warn('Firestore getPhrases fallback active:', err);
      }
    }

    if (!phrasesCache) {
      phrasesCache = phrasesJson as KannadaPhrase[];
    }
  }

  if (!category || category === 'All') {
    return phrasesCache;
  }
  return phrasesCache.filter((p) => p.category.toLowerCase() === category.toLowerCase());
}

/**
 * 4. Get Transport Options
 * Uses equality filters only (no composite indexes required) or queries and filters in memory.
 */
export async function getTransport(
  from: string = 'Bengaluru',
  to: string = 'Hampi',
  type?: 'bus' | 'train' | 'cab'
): Promise<TransportOption[]> {
  if (!transportCache) {
    try {
      const snap = await getDocs(collection(db, 'transport'));
      if (!snap.empty) {
        transportCache = snap.docs.map((d) => ({ id: d.id, ...d.data() } as unknown as TransportOption));
      }
    } catch (err) {
      console.warn('Firestore getTransport fallback active:', err);
    }
    if (!transportCache || transportCache.length === 0) {
      transportCache = transportJson as unknown as TransportOption[];
    }
  }

  let list = transportCache;
  if (type) {
    list = list.filter((t) => t.mode === type || (t as any).type === type);
  }
  if (from && to) {
    const fromN = from.toLowerCase();
    const toN = to.toLowerCase();
    const matched = list.filter((t) => {
      const it = t as any;
      return it.from?.toLowerCase().includes(fromN) && it.to?.toLowerCase().includes(toN);
    });
    if (matched.length > 0) return matched;
  }
  return list;
}

/**
 * 5. Save Trip
 * Persists to Firestore users/{uid}/trips/{tripId} for signed-in users, or localStorage for guests.
 */
export async function saveTrip(trip: Trip, uid?: string | null): Promise<void> {
  // Always mirror in localStorage for immediate offline resilience
  try {
    const stored = localStorage.getItem(STORAGE_SAVED_TRIPS_KEY);
    let trips: Trip[] = stored ? JSON.parse(stored) : [];
    const idx = trips.findIndex((t) => t.id === trip.id);
    if (idx >= 0) {
      trips[idx] = trip;
    } else {
      trips.unshift(trip);
    }
    localStorage.setItem(STORAGE_SAVED_TRIPS_KEY, JSON.stringify(trips));
  } catch (e) {
    console.warn('LocalStorage save trip notice:', e);
  }

  // If authenticated, persist to Firestore
  if (uid) {
    const tripRef = doc(db, 'users', uid, 'trips', trip.id);
    const validatedData = {
      title: String(trip.title || 'Karnataka Trip').slice(0, 120),
      destination: String(trip.destination || 'Hampi'),
      destinationId: String(trip.destinationId || 'hampi'),
      totalDays: Math.min(Math.max(Number(trip.totalDays) || 3, 1), 7),
      estimatedBudget: Number(trip.estimatedBudget) || 5000,
      preferences: (trip as any).preferences || {},
      days: Array.isArray(trip.days) ? trip.days.slice(0, 7) : [],
      meta: (trip as any).meta || {},
      schemaVersion: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await setDoc(tripRef, validatedData, { merge: true });
  }
}

/**
 * 6. List Trips
 * Queries users/{uid}/trips with orderBy createdAt desc, limit 20 via getDocs.
 * Falls back to localStorage for guests.
 */
export async function listTrips(uid?: string | null): Promise<Trip[]> {
  if (uid) {
    try {
      const q = query(collection(db, 'users', uid, 'trips'), orderBy('createdAt', 'desc'), limit(20));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map((d) => ({ id: d.id, ...d.data() } as unknown as Trip));
      }
    } catch (err) {
      console.warn('Firestore listTrips notice (falling back to localStorage):', err);
    }
  }

  // Fallback to localStorage
  try {
    const stored = localStorage.getItem(STORAGE_SAVED_TRIPS_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {}
  return [];
}

/**
 * 7. Get Single Trip
 */
export async function getTrip(tripId: string, uid?: string | null): Promise<Trip | null> {
  if (uid) {
    try {
      const snap = await getDoc(doc(db, 'users', uid, 'trips', tripId));
      if (snap.exists()) {
        return { id: snap.id, ...snap.data() } as unknown as Trip;
      }
    } catch (e) {
      console.warn('Firestore getTrip notice:', e);
    }
  }

  // Fallback to localStorage
  const list = await listTrips(uid);
  return list.find((t) => t.id === tripId) || null;
}

/**
 * 8. Delete Trip
 */
export async function deleteTrip(tripId: string, uid?: string | null): Promise<void> {
  if (uid) {
    try {
      await deleteDoc(doc(db, 'users', uid, 'trips', tripId));
    } catch (e) {
      console.warn('Firestore deleteTrip notice:', e);
    }
  }

  try {
    const stored = localStorage.getItem(STORAGE_SAVED_TRIPS_KEY);
    if (stored) {
      const trips: Trip[] = JSON.parse(stored);
      const filtered = trips.filter((t) => t.id !== tripId);
      localStorage.setItem(STORAGE_SAVED_TRIPS_KEY, JSON.stringify(filtered));
    }
  } catch {}
}

/**
 * 9. Toggle Saved Place
 * Uses deterministic ID: a_${place.id}
 */
export async function toggleSavedPlace(
  place: { id: string; destinationId?: string },
  uid?: string | null
): Promise<{ saved: boolean }> {
  const placeId = place.id;
  const docId = placeId.startsWith('a_') ? placeId : `a_${placeId}`;

  // Read current saved set from localStorage
  let savedSet = new Set<string>();
  try {
    const raw = localStorage.getItem(STORAGE_SAVED_PLACES_KEY);
    if (raw) savedSet = new Set(JSON.parse(raw));
  } catch {}

  const willBeSaved = !savedSet.has(placeId);
  if (willBeSaved) {
    savedSet.add(placeId);
  } else {
    savedSet.delete(placeId);
  }
  localStorage.setItem(STORAGE_SAVED_PLACES_KEY, JSON.stringify(Array.from(savedSet)));

  // If signed in, update Firestore with deterministic docId
  if (uid) {
    try {
      const ref = doc(db, 'users', uid, 'savedPlaces', docId);
      if (willBeSaved) {
        await setDoc(ref, {
          destinationId: place.destinationId || 'hampi',
          attractionId: placeId,
          createdAt: serverTimestamp()
        });
      } else {
        await deleteDoc(ref);
      }
    } catch (err) {
      console.warn('Firestore toggleSavedPlace notice:', err);
    }
  }

  return { saved: willBeSaved };
}

/**
 * 10. List Saved Places
 */
export async function listSavedPlaces(uid?: string | null): Promise<string[]> {
  if (uid) {
    try {
      const snap = await getDocs(collection(db, 'users', uid, 'savedPlaces'));
      if (!snap.empty) {
        return snap.docs.map((d) => d.data().attractionId || d.id.replace('a_', ''));
      }
    } catch (e) {
      console.warn('Firestore listSavedPlaces notice:', e);
    }
  }

  try {
    const raw = localStorage.getItem(STORAGE_SAVED_PLACES_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

/**
 * 11. Save User Profile
 */
export async function saveUserProfile(uid: string, data: any): Promise<void> {
  const userRef = doc(db, 'users', uid);
  await setDoc(userRef, { ...data, updatedAt: serverTimestamp() }, { merge: true });
}

export { db };

export async function initAndSeedDatabase(): Promise<void> {
  try {
    await getDestinations();
  } catch (err) {
    console.debug('initAndSeedDatabase fallback note:', err);
  }
}

