import { auth } from './firebase';

/**
 * Client helper for /api/ai/* endpoints.
 * Automatically attaches Authorization: Bearer <fresh ID token> when user is signed in.
 * Guests send no Authorization header.
 * On 401, forces token refresh once and retries once.
 */
export async function postAi<T = any>(endpoint: string, body: any): Promise<T> {
  const url = endpoint.startsWith('/api') ? endpoint : `/api${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;

  const makeRequest = async (forceTokenRefresh = false): Promise<Response> => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json'
    };

    if (auth.currentUser) {
      try {
        const token = await auth.currentUser.getIdToken(forceTokenRefresh);
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }
      } catch (err) {
        console.warn('[AI Client] Failed to retrieve user ID token:', err);
      }
    }

    return fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
  };

  let res = await makeRequest(false);

  // If 401, force token refresh and retry once if user is authenticated
  if (res.status === 401 && auth.currentUser) {
    console.info('[AI Client] 401 received, refreshing ID token and retrying...');
    res = await makeRequest(true);
    if (res.status === 401) {
      throw new Error('Please sign in again.');
    }
  }

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    const message = errorData?.error?.message || `Request failed with status ${res.status}`;
    throw new Error(message);
  }

  return res.json();
}
