# Tiruga ತಿರು ಗ: AI-Powered Karnataka Travel Companion

> **Intelligent, culturally-rooted Karnataka travel planning with real-time budget optimization, weather contingencies, and an authentic Kannada companion.**

[![React](https://img.shields.io/badge/React-18.3-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.5-3178C6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-6.0-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-4.0-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Express](https://img.shields.io/badge/Express-4.21-000000?logo=express&logoColor=white)](https://expressjs.com/)
[![Gemini 2.5 Flash](https://img.shields.io/badge/Google_Gemini-2.5_Flash-4285F4?logo=google&logoColor=white)](https://ai.google.dev/)
[![Firebase Firestore](https://img.shields.io/badge/Firebase-Firestore-FFCA28?logo=firebase&logoColor=black)](https://firebase.google.com/)

**Live Demo**: `https://tiruga-karnataka.aistudio-build.app` *(or your deployed Cloud Run service URL)*

### Screenshots
| Home & Search | 3-Day Plan & Timeline | Budget Optimizer | Kannada Companion |
|:---:|:---:|:---:|:---:|
| `docs/screenshots/01-home.png` | `docs/screenshots/02-itinerary.png` | `docs/screenshots/03-cheaper.png` | `docs/screenshots/04-kannada.png` |

---

## 1. Problem Statement
Travellers visiting Karnataka frequently encounter fragmented planning hurdles:
- **Language & Cultural Nuances**: Understanding local etiquette at sacred heritage sites (such as Hampi's Virupaksha or Pattadakal) and navigating daily conversations in Kannada without robotic translations.
- **Budget Uncertainty**: Hidden costs, ambiguous transit tariffs, and lack of awareness of local state transit alternatives (such as KSRTC State Sarige or NWKRTC).
- **Rigid Schedules vs. Unpredictable Climate**: Heavy monsoons in the Western Ghats or scorching mid-day heat in North Karnataka often ruin static itineraries without contingency options.

This application was engineered for the **Kannada Digital Innovation Hackathon 2026** under the theme **"Code. Create. Celebrate Kannada."** directly answering the challenge statement **"AI Travel Planner for Karnataka"**.

---

## 2. Solution
**Tiruga (ತಿರು ಗ)** unites cultural awareness with practical travel engineering:
- **Personalized Karnataka Itineraries**: Generated dynamically via Google Gemini 2.5 Flash with deterministic budgeting and local spatial knowledge.
- **Practical Kannada Companion**: Contextual phrases categorized by real-life situations (food, transport, shopping, emergency) with phonetic transliteration and speech synthesis.
- **Local Culture Guide**: On-demand advice for temple etiquette, photography rules, dress codes, and local culinary traditions.
- **Make It Cheaper (Budget Optimizer)**: One-tap algorithmic budget reduction highlighting local alternatives.
- **Adaptive Plan B**: Instant contingency replanning for rain, excessive heat, or site closures with replace & undo controls.

---

## 3. Key Features
- **AI Trip Planner**: Tailored itineraries matching duration (1–7 days), budget limits (₹3,000–₹50,000), travel companions (Solo, Family, Friends, Couple), and interests (Heritage, Nature, Food, Pilgrimage).
- **Modify with AI**: Natural-language itinerary adjustments (e.g., "Add more coffee plantation walks" or "Make it senior-friendly").
- **Make It Cheaper (Budget Optimizer)**: Clear before/after comparison with itemized savings (KSRTC bus links, North Karnataka Khanavali dining, ASI composite passes).
- **Plan B Weather Contingency**: Replaces exposed outdoor spots with indoor museums, covered corridors, and artisan centers upon sudden rain or heatwave.
- **Culture Guide ("Ask About This Place")**: Contextual AI answers for heritage etiquette with confidence ratings.
- **Kannada Companion**: 24+ core phrases across daily travel categories with English phonetic guides, Kannada script, and audio synthesis. Includes situational custom generator.
- **Nearby Attractions**: Interactive illustrative SVG map displaying spatial proximity and attraction pins across Karnataka.
- **Travel Options**: Overview of bus routes, trains, and cabs (labeled transparently as demo data).
- **Saved Trips & Places**: Cloud-synced user bookmarks stored in Cloud Firestore under authenticated user scopes.
- **Offline Mode**: Production Service Worker caching and local storage persistence ensuring uninterrupted viewing of saved plans without internet connectivity.
- **Bilingual Interface**: Seamless toggle between English and Kannada (ಕನ್ನಡ).

---

## 4. AI Architecture & Flow
All AI requests are handled securely by an Express backend gateway:

1. **User Preferences**: The client submits destination, days, budget, companion, and interest tags.
2. **Context Enrichment**: The server injects curated catalog attractions and heritage background into the prompt.
3. **Structured Generation**: Google Gemini 2.5 Flash (`@google/genai`) processes the query with a strict JSON schema and regional guidelines.
4. **Validation & Fallback**: The server verifies the JSON schema, validates cost sums and times, and returns the structured itinerary. If external network is down, the client seamlessly falls back to pre-validated regional itineraries.
5. **Client Rendering & Persistence**: The client renders the responsive timeline with day tabs, cost labels, and reasoning chips, persisting the trip to Cloud Firestore (`users/{uid}/trips/{id}`).

Refer to [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for full Mermaid sequence diagrams.

---

## 5. Tech Stack
- **Frontend**: React 18.3, TypeScript 5.5, Vite 6.0, Tailwind CSS 4.0.
- **Backend**: Node.js & Express 4.21, running in unified server mode via `tsx server/index.ts`.
- **AI Model**: Google Gemini 2.5 Flash via official `@google/genai` TypeScript SDK.
- **Database & Auth**: Google Cloud Firestore & Firebase Authentication (Google Sign-In + Anonymous Guest).
- **Icons**: Lucide React.
- **Typography**: Google Fonts — Inter & Noto Sans Kannada.

---

## 6. Getting Started / Local Setup

### Prerequisites
- Node.js 20+
- npm 9+
- A Google Gemini API Key

### Installation & Environment
1. Clone the repository and install dependencies:
   ```bash
   npm install
   ```
2. Configure environment variables in `.env` (refer to `.env.example`):
   ```bash
   # Server-side Secrets (never exposed in frontend)
   GEMINI_API_KEY=your_gemini_api_key_here
   SEED_SECRET=your_admin_seed_secret_here
   SEED_ENABLED=true
   PORT=3000

   # Public Client Variables
   VITE_FIREBASE_API_KEY=your_firebase_api_key
   VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your_project_id
   VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
   VITE_FIREBASE_APP_ID=your_app_id
   VITE_FIREBASE_FIRESTORE_DATABASE_ID=(default)
   ```
3. Seed the local or Firestore database:
   ```bash
   npm run seed
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

---

## 7. Deployment (Cloud Run)
Tiruga is packaged to run as a production Node.js service container on Google Cloud Run:

1. **Build the Application**:
   ```bash
   npm run build
   ```
2. **Start the Production Server**:
   ```bash
   npm start
   ```
   The Express server serves static assets from `dist/` and mounts `/api/*` routes, listening dynamically on `process.env.PORT || 3000`.
3. **Health Check Endpoint**:
   Cloud Run liveness probe target: `GET /api/health` returns `{"status":"ok"}`.
4. **Authorized Domains**:
   In the Firebase Console under **Authentication > Settings > Authorized domains**, add your Cloud Run host domain (e.g. `your-service-xyz-uc.a.run.app`).

---

## 8. Firestore Data Model
Tiruga enforces a declarative data schema defined in `firebase-blueprint.json` and secured by `firestore.rules`:

| Collection | Path | Access Rule | Description |
|---|---|---|---|
| `destinations` | `/destinations/{id}` | Read-only | Curated Karnataka destinations (Hampi, Coorg, Mysuru, etc.) |
| `attractions` | `/destinations/{id}/attractions/{aid}` | Read-only | Monuments, temples, nature trails with lat/lng & map coords |
| `phrases` | `/phrases/{id}` | Read-only | Kannada phrasebook entries with pronunciations |
| `transport` | `/transport/{id}` | Read-only | Demo transport schedules (KSRTC, Trains, Cabs) |
| `users` | `/users/{uid}` | Owner Only | Profile settings, travel style, language preference |
| `trips` | `/users/{uid}/trips/{tripId}` | Owner Only | Full itineraries with embedded days and reason chips |
| `savedPlaces` | `/users/{uid}/savedPlaces/{id}` | Owner Only | User-bookmarked attractions |

---

## 9. Security & Privacy
- **Client Zero-Secret Guarantee**: `GEMINI_API_KEY`, `SEED_SECRET`, and Google Service Account keys are never bundled into `src/` or `dist/`. All AI and admin operations execute strictly server-side.
- **Owner-Isolated Firestore Rules**: User documents, trips, and saved places can only be created, read, or modified by the authenticated user (`request.auth.uid == uid`).
- **Timing-Safe Seed Authentication**: The `POST /api/admin/seed` endpoint verifies the `X-Seed-Secret` header using `crypto.timingSafeEqual` with length validation to resist timing attacks.
- **Production Guard**: Seeding routes are disabled automatically when `SEED_ENABLED !== "true"` or `NODE_ENV === "production"`.

---

## 10. Kannada Language Support
- **Typography**: Rendered using `@fontsource/noto-sans-kannada` to ensure all conjunct consonants (ಒತ್ತಕ್ಷರಗಳು) render cleanly without tofu boxes or misaligned glyphs across all viewports.
- **Speech Synthesis**: The Kannada Companion utilizes Web Speech API (`kn-IN`). If the host device lacks a native Kannada voice pack, a friendly banner informs the user while displaying the exact phonetic romanization.
- **Authenticity Disclaimer**: Phrase translations have been authored with regional accuracy; review by native speakers is continuously incorporated.

---

## 11. Verification & Testing
Tiruga passed an exhaustive QA audit across all core user flows:
- **Routes & Deep Linking**: `/`, `/home`, `/plan`, `/trip/:id`, `/travel-options`, `/plan-b`, `/kannada`, `/nearby`, `/offline`, `/saved`, `/profile` verified without 404s.
- **Layout & Viewport**: Verified without horizontal body scrolling at `360px`, `390px` (iPhone 14), and `430px` (iPhone 14 Pro Max).
- **Touch Targets**: Minimum 44×44px interactive touch targets across buttons, chips, and navigation.
- **Data Labeling Integrity**: All non-live transport data is explicitly flagged `(Demo data)`, weather as `(Simulated)`, and costs as `Estimated`. Emergency hotline specifies `112 (Verify locally)`.

---

## 12. Hackathon Compliance, Known Limitations & Future Scope

### Hackathon Compliance
- **Theme**: "Code. Create. Celebrate Kannada."
- **Focus**: Promoting Karnataka culture, tourism accessibility, and Kannada language appreciation through AI.
- **Data Responsibility**: Transparent labeling of estimated prices and demo transport routes.

### Known Limitations
- Real-time GPS vehicle tracking for KSRTC buses is simulated via demo timetables (live KSRTC GPS API integration is currently restricted).
- Client speech synthesis depends on device-level installation of the Google Indic / Android `kn-IN` voice pack.

### Future Scope
- Integration with official KSTDC (Karnataka State Tourism Development Corporation) booking portals.
- Offline audio phrase audio packs (pre-recorded OGG/MP3 files by native artists).
- Group trip collaborative editing using Firestore real-time listeners.
