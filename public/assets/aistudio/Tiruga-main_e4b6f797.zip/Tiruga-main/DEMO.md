# Tiruga (ತಿರು ಗ) — 3-Minute Hackathon Demo Script

> **Theme**: Code. Create. Celebrate Kannada.  
> **Track**: AI Travel Planner for Karnataka (Kannada Digital Innovation Hackathon 2026)  
> **Presenter Target Time**: 3 minutes (180 seconds)

---

## 1. Quick Glance Timetable

| Time | Segment | Focus & Action |
|---|---|---|
| **0:00 – 0:25** | **The Hook & Problem** | Pitch Karnataka travel dilemma (rich culture, language barrier, unpredictable weather & budget leakages). Open Tiruga home. |
| **0:25 – 0:55** | **AI Trip Planning** | Pick "3 Days, ₹7,000, Friends, Nature + Culture". Generate Hampi plan. Show day tabs, timeline, reason chips & "Estimated" costs. |
| **0:55 – 1:25** | **Make It Cheaper (Budget Optimizer)** | Tap "Make it cheaper". Reveal Before/After card (₹7,000 → ₹4,200), savings breakdown, tap "Apply Savings". |
| **1:25 – 1:55** | **Kannada Companion** | Tap Kannada icon. Show restaurant phrase with Kannada script, pronunciation, and tap **Listen** audio button. |
| **1:55 – 2:20** | **Culture Guide ("Ask About This Place")** | Tap "Ask about this place" on Virupaksha Temple. Instant answer with confidence badge on temple dress code. |
| **2:20 – 2:45** | **Adaptive Plan B (Rain Contingency)** | Trigger Rain contingency: switch outdoor boulders to indoor ASI museum & undercover carvings. Show Replace & Undo. |
| **2:45 – 3:00** | **Closing & Architecture** | Highlight server-side Gemini 2.5 Flash, Firestore persistence, offline caching, and native Kannada-first UI. |

---

## 2. Step-by-Step Demo Flow

### Step 1: Launch & Preferences (0:00 – 0:25)
1. **URL**: Navigate to `http://localhost:3000` (or the deployed Cloud Run domain).
2. **Onboarding / Home**: Point out the clean mobile viewport (390px/430px) and bilingual header (**ತಿರು ಗ / Tiruga**).
3. **Select Inputs**:
   - Tap **Plan a Trip** (or navigate to `/plan`).
   - Destination: **Hampi** (Heritage & Boulders).
   - Duration: **3 Days**.
   - Budget: **₹7,000** (Demo preset: ₹2,333/day).
   - Companion / Style: **Friends** · **Nature + Culture**.
4. **Generate**: Tap **Generate My Itinerary**.

### Step 2: The Generated Plan (0:25 – 0:55)
1. **Showcase Hero**:
   - Point out the **AI-generated** gold badge and **Estimated** budget tag.
   - Flip across **Day 1**, **Day 2**, and **Day 3** tabs.
2. **Timeline Items**:
   - Highlight **Virupaksha Temple**, **Vijaya Vittala Musical Pillars**, **Matanga Hill Sunrise**.
   - Highlight the **"Why picked"** reasoning tags tailored to "Friends + Culture".

### Step 3: Make It Cheaper (0:55 – 1:25)
1. Tap **Make it cheaper (Budget Optimizer)**.
2. The bottom sheet animates up:
   - **Before**: `₹7,000` → **After**: `₹4,200` (Save `₹2,800`).
   - Breakdown:
     - *KSRTC State Sarige & Walkable Routes* (-₹1,200)
     - *Authentic North Karnataka Khanavali Thali (Jolada rotti)* (-₹800)
     - *ASI Pass & Free Morning Ghats* (-₹800)
3. Tap **Apply Savings**. Notice the total updates instantly and persists.

### Step 4: Kannada Companion (1:25 – 1:55)
1. Tap the **Kannada** tab in the bottom navigation (or quick tile on Home).
2. Category: Select **Food & Dining** (ಊಟ ಮತ್ತು ಉಪಹಾರ).
3. Card: Select *"Is this food spicy?"* / **"ಇದು ಖಾರವಾಗಿದೆಯೇ?"** (*Idu khāravāgidiyē?*).
4. Tap the **Listen** (🔊) button: Hear speech synthesis with automatic fallback notice if Kannada voice pack is not installed locally.
5. Tap **Generate for my situation** to demonstrate situational dynamic phrase generator.

### Step 5: Ask About This Place (1:55 – 2:20)
1. Open Trip Plan, find **Virupaksha Temple**, and tap **"Ask about this place"**.
2. Select suggested query chip: *"What should I wear at Virupaksha Temple?"*
3. The AI returns cultural guidelines: Traditional attire recommended, shoulders and knees covered, footwear deposited at the ASI northern gate counter, with a **High Confidence (95%)** badge.

### Step 6: Plan B Weather Contingency (2:20 – 2:45)
1. Open **Plan B** (`/plan-b`).
2. Condition: Choose **Sudden Heavy Rain** (ಮಳೆ).
3. Tap **Generate Contingency Plan**.
4. Show how outdoor climbs are replaced by indoor Kamal Mahal ASI museum, Queen's Bath corridor, and protected pavilions.
5. Tap **Replace this day** (with immediate **Undo** option available).

---

## 3. Demo Shortcuts & Stage Backup (`?demo=1`)

If live conference Wi-Fi is slow or unstable:
1. Append `?demo=1` to any URL (e.g. `http://localhost:3000/?demo=1`).
2. An expandable **Demo Tools** floating badge appears in the bottom-left corner:
   - **Load Backup Itinerary**: Loads the pre-generated, validated 3-Day Hampi itinerary (`data/demoTrip.json`) in `< 50ms`.
   - **Fill Demo Preferences**: Pre-populates 3 days, ₹7,000, Friends, Nature + Culture with 1 tap.
   - **Reset Demo State**: Clears temporary local data and resets clean.
3. This guarantees a zero-latency, 100% reliable stage presentation under any network condition.

---

## 4. Pre-Demo Checklist
- [x] Run `npm run build` to confirm zero compilation errors.
- [x] Server listening on `PORT=3000` with `GET /api/health` returning `{"status":"ok"}`.
- [x] Tested on 390px (iPhone 14) and 430px (iPhone 14 Pro Max) viewport widths.
- [x] Offline Service Worker cached for resilient reloads.
- [x] Client bundle audited: 0 API keys or service accounts exposed in frontend.
