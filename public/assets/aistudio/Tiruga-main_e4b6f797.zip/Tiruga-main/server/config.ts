import dotenv from 'dotenv';
dotenv.config();

/**
 * Server-only configuration.
 * Validates environment variables at startup.
 * CRITICAL: Never import this file in client code (src/).
 */
export interface ServerConfig {
  geminiApiKey: string;
  geminiModel: string;
  seedEnabled: boolean;
  seedSecret: string;
  port: number;
  nodeEnv: string;
  allowedOrigins: string[];
}

const missingRequired: string[] = [];

const geminiApiKey = process.env.GEMINI_API_KEY || '';
if (!geminiApiKey) {
  missingRequired.push('GEMINI_API_KEY');
}

const seedSecret = process.env.SEED_SECRET || '';
if (!seedSecret && process.env.SEED_ENABLED === 'true') {
  missingRequired.push('SEED_SECRET');
}

// Log missing variables by NAME only, never by value
if (missingRequired.length > 0) {
  console.warn(`[Config] Missing environment variables: ${missingRequired.join(', ')}`);
}

// In production, the server must refuse to start if GEMINI_API_KEY is missing
if (process.env.NODE_ENV === 'production' && !geminiApiKey) {
  console.error('[Config Fatal] GEMINI_API_KEY is required in production. Server cannot start.');
  process.exit(1);
}

const rawOrigins = process.env.ALLOWED_ORIGINS || '';
const allowedOrigins = rawOrigins
  ? rawOrigins.split(',').map((o) => o.trim()).filter(Boolean)
  : [];

export const config: ServerConfig = {
  geminiApiKey,
  geminiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
  seedEnabled: process.env.SEED_ENABLED === 'true',
  seedSecret,
  port: Number(process.env.PORT) || (process.env.NODE_ENV === 'production' ? 8080 : 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  allowedOrigins
};
