import admin from 'firebase-admin';
import firebaseConfig from '../firebase-applet-config.json';

/**
 * Server-only Firebase Admin initialization.
 * Uses Application Default Credentials (ADC) on Google Cloud Run,
 * or fallback project configuration for local dev simulation.
 * CRITICAL: Never import this file into src/.
 */
if (!admin.apps.length) {
  try {
    admin.initializeApp({
      projectId: process.env.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId
    });
  } catch (err) {
    console.warn('[Firebase Admin] Initialization note:', err);
  }
}

export const adminDb = admin.firestore();
export const adminAuth = admin.auth();

export { admin };
