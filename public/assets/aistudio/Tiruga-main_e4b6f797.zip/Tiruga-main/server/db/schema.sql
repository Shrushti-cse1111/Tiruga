-- Tiruga (ತಿರುಗ) Karnataka Travel Planner Database Schema
-- Standard SQLite DDL

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone_hash TEXT,
  pin_hash TEXT,
  lang TEXT NOT NULL DEFAULT 'en',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS traveller_profiles (
  user_id TEXT PRIMARY KEY,
  is_woman INTEGER NOT NULL DEFAULT 1,
  karnataka_domicile INTEGER NOT NULL DEFAULT 1,
  senior_mode INTEGER NOT NULL DEFAULT 0,
  large_text INTEGER NOT NULL DEFAULT 0,
  travel_style TEXT NOT NULL DEFAULT 'solo',
  default_budget_inr REAL NOT NULL DEFAULT 6000,
  interests TEXT NOT NULL, -- JSON array of strings
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS regions (
  id TEXT PRIMARY KEY,
  name_en TEXT NOT NULL,
  name_kn TEXT NOT NULL,
  name_mr TEXT NOT NULL,
  description TEXT NOT NULL,
  districts TEXT NOT NULL, -- JSON array
  best_months TEXT NOT NULL, -- JSON array
  last_checked TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS places (
  id TEXT PRIMARY KEY,
  region_id TEXT NOT NULL,
  name_en TEXT NOT NULL,
  name_kn TEXT NOT NULL,
  name_mr TEXT NOT NULL,
  category TEXT NOT NULL,
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  description_en TEXT NOT NULL,
  description_kn TEXT NOT NULL,
  description_mr TEXT NOT NULL,
  hours_open TEXT NOT NULL,
  hours_close TEXT NOT NULL,
  hours_notes TEXT,
  entry_fee_inr REAL NOT NULL DEFAULT 0,
  typical_visit_minutes INTEGER NOT NULL DEFAULT 60,
  dress_code TEXT NOT NULL,
  rules TEXT NOT NULL, -- JSON array
  quiet_alternative_id TEXT,
  base_crowd_score INTEGER NOT NULL DEFAULT 5,
  is_indoor INTEGER NOT NULL DEFAULT 0,
  is_heritage INTEGER NOT NULL DEFAULT 0,
  last_checked TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  photo_url TEXT,
  FOREIGN KEY (region_id) REFERENCES regions(id)
);

CREATE TABLE IF NOT EXISTS stays (
  id TEXT PRIMARY KEY,
  region_id TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price_per_night_inr REAL NOT NULL,
  rating REAL NOT NULL,
  amenities TEXT NOT NULL, -- JSON array
  last_checked TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (region_id) REFERENCES regions(id)
);

CREATE TABLE IF NOT EXISTS food_spots (
  id TEXT PRIMARY KEY,
  region_id TEXT NOT NULL,
  name TEXT NOT NULL,
  speciality TEXT NOT NULL,
  category TEXT NOT NULL,
  veg_only INTEGER NOT NULL DEFAULT 0,
  cost_for_two_inr REAL NOT NULL,
  opening_hours TEXT NOT NULL,
  last_checked TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (region_id) REFERENCES regions(id)
);

CREATE TABLE IF NOT EXISTS transport_legs (
  id TEXT PRIMARY KEY,
  from_city TEXT NOT NULL,
  to_city TEXT NOT NULL,
  mode TEXT NOT NULL,
  operator TEXT NOT NULL,
  service_class TEXT NOT NULL,
  departure_time TEXT NOT NULL,
  arrival_time TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL,
  fare_inr REAL NOT NULL,
  shakti_eligible INTEGER NOT NULL DEFAULT 0,
  frequency TEXT NOT NULL,
  booking_url TEXT NOT NULL,
  notice TEXT,
  last_checked TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS trips (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  region_id TEXT NOT NULL,
  days_count INTEGER NOT NULL,
  budget_total_inr REAL NOT NULL,
  travel_style TEXT NOT NULL,
  shakti_active INTEGER NOT NULL DEFAULT 1,
  responsible_score INTEGER NOT NULL DEFAULT 85,
  created_at TEXT NOT NULL,
  active_plan_b TEXT, -- NULL if normal, 'rain' | 'heat' etc if active
  days_data TEXT NOT NULL, -- JSON representation of days & stops
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agent_runs (
  id TEXT PRIMARY KEY,
  trip_id TEXT NOT NULL,
  agent_name TEXT NOT NULL,
  input_summary TEXT NOT NULL,
  output_summary TEXT NOT NULL,
  duration_ms INTEGER NOT NULL,
  timestamp TEXT NOT NULL,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS saved_places (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  place_id TEXT NOT NULL,
  saved_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (place_id) REFERENCES places(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS emergency_contacts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS offline_packs (
  trip_id TEXT PRIMARY KEY,
  data_bundle TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE
);
