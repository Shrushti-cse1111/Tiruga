import {
  User,
  TravellerProfile,
  Region,
  Place,
  Stay,
  FoodSpot,
  TransportLeg,
  Trip,
  AgentRun,
  SavedPlace,
  EmergencyContact,
  OfflinePack
} from '../../shared/types';
import { SEED_REGIONS, SEED_RULES_CONFIG } from '../../shared/data/seedData';
import {
  SEED_PLACES_ALL,
  SEED_STAYS_ALL,
  SEED_FOOD_SPOTS_ALL,
  SEED_TRANSPORT_LEGS_ALL
} from '../../shared/data/seedPlaces';

class ServerDatabase {
  public users: Map<string, User> = new Map();
  public profiles: Map<string, TravellerProfile> = new Map();
  public regions: Map<string, Region> = new Map();
  public places: Map<string, Place> = new Map();
  public stays: Map<string, Stay> = new Map();
  public foodSpots: Map<string, FoodSpot> = new Map();
  public transportLegs: Map<string, TransportLeg> = new Map();
  public trips: Map<string, Trip> = new Map();
  public agentRuns: AgentRun[] = [];
  public savedPlaces: Map<string, SavedPlace> = new Map();
  public emergencyContacts: Map<string, EmergencyContact> = new Map();
  public offlinePacks: Map<string, OfflinePack> = new Map();
  public rules: any = SEED_RULES_CONFIG;

  constructor() {
    this.seed();
  }

  public seed() {
    // Default user
    const defaultUser: User = {
      id: 'usr_server_default',
      name: 'Karnataka Yatri',
      phone_hash: null,
      pin_hash: null,
      lang: 'en',
      created_at: new Date().toISOString()
    };
    this.users.set(defaultUser.id, defaultUser);

    this.profiles.set(defaultUser.id, {
      user_id: defaultUser.id,
      is_woman: true,
      karnataka_domicile: true,
      senior_mode: false,
      large_text: false,
      travel_style: 'solo',
      default_budget_inr: 6000,
      interests: ['heritage', 'food']
    });

    // Seed regions
    for (const r of SEED_REGIONS) {
      this.regions.set(r.id, r);
    }

    // Seed places
    for (const p of SEED_PLACES_ALL) {
      this.places.set(p.id, p);
    }

    // Seed stays
    for (const s of SEED_STAYS_ALL) {
      this.stays.set(s.id, s);
    }

    // Seed food spots
    for (const f of SEED_FOOD_SPOTS_ALL) {
      this.foodSpots.set(f.id, f);
    }

    // Seed transport legs
    for (const t of SEED_TRANSPORT_LEGS_ALL) {
      this.transportLegs.set(t.id, t);
    }

    // Default emergency contact
    this.emergencyContacts.set('emg_default', {
      id: 'emg_default',
      user_id: defaultUser.id,
      name: 'Karnataka Tourist Helpline',
      phone: '1800-425-2425'
    });
  }
}

export const serverDb = new ServerDatabase();
