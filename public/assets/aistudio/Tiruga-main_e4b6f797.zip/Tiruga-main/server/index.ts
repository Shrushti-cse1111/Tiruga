import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { config } from './config';
import { securityHeaders } from './middleware/security';
import { requestLogger } from './utils/logger';
import { apiRouter } from './routes/index';
import { apiNotFoundHandler, globalErrorHandler } from './middleware/errors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

export async function createServer() {
  const app = express();
  const isProd = config.nodeEnv === 'production';

  // 1. Trust proxy for Cloud Run so req.ip and rate limiters work properly
  app.set('trust proxy', 1);

  // 2. Remove X-Powered-By
  app.disable('x-powered-by');

  // 3. Security headers & CORS
  app.use(securityHeaders);

  // 4. Structured safe request logger
  app.use(requestLogger);

  // 5. Body parser strictly limited to 20 KB
  app.use(express.json({ limit: '20kb' }));

  // 6. Service Worker route with required PWA headers
  app.get('/sw.js', (req: Request, res: Response) => {
    const swPath = path.resolve(rootDir, 'public', 'sw.js');
    if (fs.existsSync(swPath)) {
      res.setHeader('Content-Type', 'application/javascript');
      res.setHeader('Service-Worker-Allowed', '/');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.sendFile(swPath);
    } else {
      res.status(404).end();
    }
  });

  // 7. Mount all /api routes
  app.use('/api', apiRouter);

  // 8. API 404 handler for unknown /api/* routes
  app.use(apiNotFoundHandler);

  // 9. Vite middleware in development or static serving in production
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
      root: rootDir
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(rootDir, 'dist');
    app.use(express.static(distDir));

    // SPA fallback for all non-/api routes
    app.get('*', (req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith('/api')) {
        return next();
      }
      const indexPath = path.resolve(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Application build not found. Please run npm run build first.');
      }
    });
  }

  // 10. Global Error Handler (Structured JSON, no stack trace leaks)
  app.use(globalErrorHandler);

  return app;
}

// Start server if this is the main entry point
if (process.env.NODE_ENV !== 'test' && !process.env.VITEST) {
  createServer()
    .then((app) => {
      const port = config.port;
      const host = '0.0.0.0';

      // Loud warning in production if seed endpoint is enabled
      if (config.nodeEnv === 'production' && config.seedEnabled) {
        console.warn(
          '⚠️ [SECURITY WARNING] SEED_ENABLED is set to true in PRODUCTION! Please disable after seeding.'
        );
      }

      const server = app.listen(port, host, () => {
        console.log(
          `Tiruga server listening on http://${host}:${port} (${config.nodeEnv})`
        );
      });

      // Graceful shutdown on SIGTERM (Cloud Run container termination)
      process.on('SIGTERM', () => {
        console.log('Received SIGTERM, closing server gracefully...');
        server.close(() => {
          console.log('Server closed successfully.');
          process.exit(0);
        });
      });

      process.on('SIGINT', () => {
        console.log('Received SIGINT, shutting down...');
        server.close(() => {
          process.exit(0);
        });
      });
    })
    .catch((err) => {
      console.error('Failed to start server:', err?.message || err);
      process.exit(1);
    });
}
