import { Router, Request, Response } from 'express';
import { adminDb } from '../firebaseAdmin';

export const healthRouter = Router();

/**
 * GET /api/health
 * Basic liveness probe.
 */
healthRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    ok: true,
    time: new Date().toISOString()
  });
});

/**
 * GET /api/ready
 * Readiness probe testing Firestore reachability via tiny Admin read.
 * Never exposes database names or error details.
 */
healthRouter.get('/ready', async (_req: Request, res: Response) => {
  let firestoreReachable = false;
  try {
    // Perform a tiny read (limit 1) on destinations collection
    const snapshot = await adminDb.collection('destinations').limit(1).get();
    firestoreReachable = snapshot !== undefined;
  } catch (err) {
    firestoreReachable = false;
  }

  res.status(firestoreReachable ? 200 : 503).json({
    ok: firestoreReachable,
    firestore: firestoreReachable
  });
});
