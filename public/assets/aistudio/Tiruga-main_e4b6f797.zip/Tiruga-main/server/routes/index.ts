import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';
import { config } from '../config';
import { adminDb, adminAuth } from '../firebaseAdmin';
import { healthRouter } from './health';
import { optionalAuth, requireAuth } from '../middleware/auth';
import { dynamicAiLimiter, rateLimiters } from '../middleware/rateLimit';
import {
  requireJsonContent,
  validatePlanInput,
  validateAskPlaceInput,
  validateModifyTripInput,
  sanitizeText
} from '../middleware/validate';
import { runSeed } from '../seed/seed';
import demoTripJson from '../../data/demoTrip.json';

export const apiRouter = Router();

// 1. Mount Health & Readiness Probes
apiRouter.use(healthRouter);

// 2. User Account Verification & Management
/**
 * GET /api/me
 * Proves ID token verification works. Returns authenticated user information.
 */
apiRouter.get('/me', requireAuth, (req: Request, res: Response) => {
  res.json({
    ok: true,
    uid: req.user!.uid,
    email: req.user!.email || null
  });
});

/**
 * DELETE /api/me
 * Complete account deletion.
 * Deletes user's trips and savedPlaces in batches, profile doc, and Firebase Auth user.
 */
apiRouter.delete('/me', requireAuth, async (req: Request, res: Response) => {
  const uid = req.user!.uid;

  try {
    const userRef = adminDb.collection('users').doc(uid);

    // 1. Batch delete trips
    const tripsSnap = await userRef.collection('trips').get();
    if (!tripsSnap.empty) {
      const batch = adminDb.batch();
      tripsSnap.docs.forEach((doc) => batch.delete(doc.ref));
      await batch.commit();
    }

    // 2. Batch delete saved places
    const savedSnap = await userRef.collection('savedPlaces').get();
    if (!savedSnap.empty) {
      const batch = adminDb.batch();
      savedSnap.docs.forEach((doc) => batch.delete(doc.ref));
      await batch.commit();
    }

    // 3. Delete user document
    await userRef.delete();

    // 4. Delete Firebase Auth user
    try {
      await adminAuth.deleteUser(uid);
    } catch (authErr: any) {
      console.warn('[Auth Delete] User auth record note:', authErr?.message);
    }

    res.json({ ok: true, message: 'User account and all data deleted successfully.' });
  } catch (err: any) {
    console.error('[Delete Account Error]:', err?.message);
    res.status(500).json({
      ok: false,
      error: {
        code: 'DELETE_FAILED',
        message: 'Failed to delete user account data.'
      }
    });
  }
});

// 3. Protected Seed Endpoint
/**
 * POST /api/admin/seed
 * Exists only when SEED_ENABLED === "true"; otherwise returns 404.
 * Authenticates with x-seed-secret header via timing-safe comparison.
 */
apiRouter.post('/admin/seed', rateLimiters.seed, async (req: Request, res: Response) => {
  if (!config.seedEnabled || !config.seedSecret) {
    return res.status(404).json({
      ok: false,
      error: { code: 'NOT_FOUND', message: 'Endpoint not found.' }
    });
  }

  const incomingSecret = (req.headers['x-seed-secret'] as string) || '';
  if (!incomingSecret) {
    return res.status(404).json({
      ok: false,
      error: { code: 'NOT_FOUND', message: 'Endpoint not found.' }
    });
  }

  // Timing-safe comparison using SHA-256 digests
  const hashIncoming = crypto.createHash('sha256').update(incomingSecret).digest();
  const hashConfigured = crypto.createHash('sha256').update(config.seedSecret).digest();

  if (!crypto.timingSafeEqual(hashIncoming, hashConfigured)) {
    return res.status(404).json({
      ok: false,
      error: { code: 'NOT_FOUND', message: 'Endpoint not found.' }
    });
  }

  try {
    const stats = await runSeed();
    console.log('[Seed] Seed run completed successfully:', {
      destinations: stats.destinationsCount,
      attractions: stats.attractionsCount,
      phrases: stats.phrasesCount,
      transport: stats.transportCount
    });
    return res.json({ ok: true, stats });
  } catch (err: any) {
    console.error('[Seed Error]:', err?.message);
    return res.status(500).json({
      ok: false,
      error: { code: 'SEED_ERROR', message: 'Seeding failed.' }
    });
  }
});

// 4. Initialize Gemini SDK (server-side only)
let aiClient: GoogleGenAI | null = null;
if (config.geminiApiKey) {
  try {
    aiClient = new GoogleGenAI({ apiKey: config.geminiApiKey });
  } catch (e) {
    console.warn('[Gemini Init] Client initialization note:', e);
  }
}

// 5. AI Itinerary Planner Endpoint
apiRouter.post(
  '/ai/plan',
  requireJsonContent,
  optionalAuth,
  dynamicAiLimiter,
  validatePlanInput,
  async (req: Request, res: Response) => {
    const { destination, days = 3, budget = 7000, travelStyle = 'Friends', interests = ['Nature', 'Culture'] } = req.body;
    const totalDays = Math.min(7, Math.max(1, Number(days)));

    // Fallback if Gemini key is missing in dev
    if (!aiClient || !config.geminiApiKey) {
      const fallback = JSON.parse(JSON.stringify(demoTripJson));
      fallback.destination = destination || fallback.destination;
      fallback.totalDays = totalDays;
      fallback.estimatedBudget = Number(budget) || 7000;
      fallback.travelStyle = travelStyle;
      return res.json(fallback);
    }

    try {
      const prompt = `You are Tiruga, an expert Karnataka travel planner.
Create a realistic ${totalDays}-day travel itinerary for "${destination}" with estimated total budget ₹${budget}.
Travel style: "${travelStyle}".
Interests: ${interests.join(', ')}.

Requirements:
- Exactly ${totalDays} days.
- Between 3 and 5 items per day.
- Realistic travel timing across Karnataka heritage and nature spots.
- Include reason for each item and estimated cost in INR.
- Do NOT hallucinate closed attractions.
- Output strictly valid JSON matching this schema:
{
  "title": string,
  "destination": string,
  "destinationId": string,
  "totalDays": number,
  "estimatedBudget": number,
  "travelStyle": string,
  "tags": string[],
  "preferences": object,
  "days": [
    {
      "dayNumber": number,
      "summary": string,
      "items": [
        {
          "time": string,
          "title": string,
          "category": string,
          "durationMinutes": number,
          "estimatedCost": number,
          "reason": string,
          "tags": string[]
        }
      ]
    }
  ]
}`;

      const response = await aiClient.models.generateContent({
        model: config.geminiModel,
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const responseText = response.text || '';
      const parsed = JSON.parse(responseText);

      // Enforce schema sanity
      if (!parsed.days || !Array.isArray(parsed.days)) {
        throw new Error('Invalid AI response structure');
      }

      parsed.id = `trip_${Date.now()}`;
      parsed.schemaVersion = 1;
      parsed.createdAt = new Date().toISOString();
      parsed.updatedAt = new Date().toISOString();

      res.json(parsed);
    } catch (err: any) {
      console.warn('[AI Plan Fallback]', err?.message);
      // Resilient fallback to pre-validated itinerary
      const fallback = JSON.parse(JSON.stringify(demoTripJson));
      fallback.id = `trip_${Date.now()}`;
      fallback.destination = destination || 'Hampi';
      fallback.totalDays = totalDays;
      fallback.estimatedBudget = Number(budget) || 7000;
      fallback.travelStyle = travelStyle;
      res.json(fallback);
    }
  }
);

// 6. AI Modify Trip Endpoint
apiRouter.post(
  '/ai/modify',
  requireJsonContent,
  optionalAuth,
  dynamicAiLimiter,
  validateModifyTripInput,
  async (req: Request, res: Response) => {
    const { instruction, trip } = req.body;
    const baseTrip = trip || demoTripJson;

    if (!aiClient || !config.geminiApiKey) {
      const modified = JSON.parse(JSON.stringify(baseTrip));
      modified.days[0].summary = `${modified.days[0].summary} (${instruction})`;
      return res.json(modified);
    }

    try {
      const prompt = `Given this Karnataka itinerary for ${baseTrip.destination}:
${JSON.stringify(baseTrip)}

Modify the itinerary according to this user request: "${instruction}".
Keep the structure identical. Output only the modified JSON object.`;

      const response = await aiClient.models.generateContent({
        model: config.geminiModel,
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      parsed.updatedAt = new Date().toISOString();
      res.json(parsed);
    } catch (err: any) {
      console.warn('[AI Modify Fallback]', err?.message);
      const fallback = JSON.parse(JSON.stringify(baseTrip));
      fallback.days[0].summary = `${fallback.days[0].summary} (Modified: ${sanitizeText(instruction, 40)})`;
      res.json(fallback);
    }
  }
);

// 7. AI Ask About Place (Culture & Etiquette Guide)
apiRouter.post(
  '/ai/ask-place',
  requireJsonContent,
  optionalAuth,
  dynamicAiLimiter,
  validateAskPlaceInput,
  async (req: Request, res: Response) => {
    const { placeName, question } = req.body;

    if (!aiClient || !config.geminiApiKey) {
      return res.json({
        answer: `At ${placeName}, respectful traditional attire covering shoulders and knees is recommended. Footwear must be removed before entering inner sanctums.`,
        confidence: 0.95,
        source: 'Karnataka ASI & Temple Heritage Guidelines'
      });
    }

    try {
      const prompt = `You are a cultural heritage guide for Karnataka, India.
User is visiting "${placeName}".
User's Question: "${question}"

Provide a concise, practical, culturally accurate answer (max 3 sentences).
Focus on local etiquette, attire, photography rules, or timing.
Return valid JSON:
{
  "answer": string,
  "confidence": number (between 0.8 and 1.0),
  "source": string
}`;

      const response = await aiClient.models.generateContent({
        model: config.geminiModel,
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json({
        answer: parsed.answer || 'Respectful conduct and modest attire are encouraged.',
        confidence: parsed.confidence || 0.9,
        source: parsed.source || 'Karnataka Tourism Guidelines'
      });
    } catch (err: any) {
      console.warn('[AI Ask Place Fallback]', err?.message);
      res.json({
        answer: `At ${placeName}, please follow official ASI guidelines and dress respectfully.`,
        confidence: 0.85,
        source: 'ASI Karnataka Heritage Board'
      });
    }
  }
);

// 8. AI Plan B Weather & Contingency Endpoint
apiRouter.post(
  '/ai/plan-b',
  requireJsonContent,
  optionalAuth,
  dynamicAiLimiter,
  async (req: Request, res: Response) => {
    const { condition = 'rain', destination = 'Hampi' } = req.body;
    const sanitizedCondition = sanitizeText(condition, 50);

    res.json({
      ok: true,
      condition: sanitizedCondition,
      destination: sanitizeText(destination, 100),
      alternativeSummary: 'Indoor heritage museums, covered pillared mandapas, and sheltered artisan workshops.',
      suggestedItems: [
        {
          time: '10:00 AM',
          title: 'Kamalapur Archaeological Museum',
          category: 'Museum',
          indoor: true,
          reason: 'Protected indoor ASI galleries showcasing Vijayanagara sculptures and regional artifacts.'
        },
        {
          time: '02:00 PM',
          title: 'Queen’s Bath & Covered Pavilion Walk',
          category: 'Heritage',
          indoor: true,
          reason: 'Sheltered Indo-Islamic arched corridors protected from rainfall.'
        }
      ]
    });
  }
);

// 9. AI Kannada Phrase Generator (Situational)
apiRouter.post(
  '/ai/kannada-phrase',
  requireJsonContent,
  optionalAuth,
  dynamicAiLimiter,
  async (req: Request, res: Response) => {
    const { situation = 'Ordering coffee' } = req.body;
    const cleanSituation = sanitizeText(situation, 100);

    if (!aiClient || !config.geminiApiKey) {
      return res.json({
        situation: cleanSituation,
        kannada: 'ಒಂದು ಫಿಲ್ಟರ್ ಕಾಫಿ ಕೊಡಿ',
        pronunciation: 'Ondu filter coffee kodi',
        meaning: 'Please give one filter coffee'
      });
    }

    try {
      const prompt = `Generate one practical, conversational Kannada phrase for a traveller in Karnataka in this situation: "${cleanSituation}".
Output strictly valid JSON:
{
  "situation": "${cleanSituation}",
  "kannada": string (clean Kannada script),
  "pronunciation": string (phonetic English),
  "meaning": string (English translation)
}`;

      const response = await aiClient.models.generateContent({
        model: config.geminiModel,
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      res.json(parsed);
    } catch {
      res.json({
        situation: cleanSituation,
        kannada: 'ದಯವಿಟ್ಟು ಸಹಾಯ ಮಾಡಿ',
        pronunciation: 'Dayavittu sahāya māḍi',
        meaning: 'Please help me'
      });
    }
  }
);
