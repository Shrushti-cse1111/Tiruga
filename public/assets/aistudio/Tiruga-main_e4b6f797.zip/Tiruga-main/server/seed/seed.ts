import { adminDb } from '../firebaseAdmin';
import destinations from '../../data/destinations.json';
import attractions from '../../data/attractions.json';
import phrases from '../../data/phrases.json';
import transport from '../../data/transport.json';

export async function runSeed(): Promise<{
  destinationsCount: number;
  attractionsCount: number;
  phrasesCount: number;
  transportCount: number;
  seededAt: string;
}> {
  console.log('Starting idempotent Firestore seed...');

  const now = new Date().toISOString();

  // Helper to commit batches in chunks of <= 400
  class BatchWriter {
    private batch = adminDb.batch();
    private count = 0;

    async set(ref: FirebaseFirestore.DocumentReference, data: any) {
      this.batch.set(ref, data, { merge: true });
      this.count++;
      if (this.count >= 400) {
        await this.commit();
      }
    }

    async commit() {
      if (this.count > 0) {
        await this.batch.commit();
        this.batch = adminDb.batch();
        this.count = 0;
      }
    }
  }

  const writer = new BatchWriter();

  // 1. Seed Destinations (destinations/{id})
  for (const dest of destinations) {
    const ref = adminDb.collection('destinations').doc(dest.id);
    await writer.set(ref, {
      name: dest.name,
      nameKn: dest.nameKn,
      district: dest.district,
      categories: dest.categories,
      tags: dest.tags,
      description: dest.description,
      image: dest.image,
      budgetLevel: dest.budgetLevel,
      bestSeason: dest.bestSeason,
      recommendedDays: dest.recommendedDays,
      familySuitable: dest.familySuitable,
      studentSuitable: dest.studentSuitable,
      foodHighlights: dest.foodHighlights,
      updatedAt: now
    });
  }
  console.log(`Prepared ${destinations.length} destinations.`);

  // 2. Seed Attractions (destinations/{destId}/attractions/{attId})
  for (const att of attractions) {
    const destId = (att as any).destinationId || 'hampi';
    const ref = adminDb.collection('destinations').doc(destId).collection('attractions').doc(att.id);
    await writer.set(ref, {
      name: att.name,
      kannadaName: att.kannadaName || '',
      category: att.category,
      durationMinutes: att.durationMinutes,
      estimatedCost: att.estimatedCost,
      indoor: att.indoor,
      description: att.description,
      lat: att.lat,
      lng: att.lng,
      mapX: att.mapX,
      mapY: att.mapY,
      image: att.image,
      sampleRating: att.sampleRating || 4.7,
      distanceKm: att.distanceKm || 1.5,
      updatedAt: now
    });
  }
  console.log(`Prepared ${attractions.length} attractions.`);

  // 3. Seed Phrases (phrases/{id})
  for (const phrase of phrases) {
    const ref = adminDb.collection('phrases').doc(phrase.id);
    await writer.set(ref, {
      category: phrase.category,
      english: phrase.english,
      kannada: phrase.kannada,
      pronunciation: phrase.pronunciation,
      situation: phrase.situation,
      updatedAt: now
    });
  }
  console.log(`Prepared ${phrases.length} phrases.`);

  // 4. Seed Transport (transport/{id})
  for (const t of transport) {
    const ref = adminDb.collection('transport').doc(t.id);
    await writer.set(ref, {
      type: t.type,
      operator: t.operator,
      from: t.from,
      to: t.to,
      departure: t.departure,
      durationMinutes: t.durationMinutes,
      stops: t.stops,
      priceEstimate: t.priceEstimate,
      isDemo: true,
      typeTag: t.typeTag || '',
      isShaktiEligible: (t as any).isShaktiEligible || false,
      updatedAt: now
    });
  }
  console.log(`Prepared ${transport.length} transport options.`);

  // 5. Write meta/seed document
  const metaRef = adminDb.collection('meta').doc('seed');
  await writer.set(metaRef, {
    version: 1,
    seededAt: now,
    destinationsCount: destinations.length,
    attractionsCount: attractions.length,
    phrasesCount: phrases.length,
    transportCount: transport.length
  });

  // Final commit
  await writer.commit();

  console.log('Firestore seed completed successfully:');
  console.log(`- Destinations: ${destinations.length}`);
  console.log(`- Attractions:  ${attractions.length}`);
  console.log(`- Phrases:      ${phrases.length}`);
  console.log(`- Transport:    ${transport.length}`);

  return {
    destinationsCount: destinations.length,
    attractionsCount: attractions.length,
    phrasesCount: phrases.length,
    transportCount: transport.length,
    seededAt: now
  };
}

export const seedAll = runSeed;

// Execute directly if run via CLI
if (import.meta.url === `file://${process.argv[1]}`) {
  runSeed()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('Seed error:', err);
      process.exit(1);
    });
}

