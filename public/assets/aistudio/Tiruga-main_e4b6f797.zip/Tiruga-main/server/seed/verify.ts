import { adminDb } from '../firebaseAdmin';

export async function verifySeed(): Promise<boolean> {
  console.log('Verifying Firestore seed counts via Firebase Admin SDK...');

  let success = true;

  try {
    // 1. Destinations (expect >= 15)
    const destSnap = await adminDb.collection('destinations').get();
    const destCount = destSnap.size;
    console.log(`- Destinations count: ${destCount} (expected >= 15)`);
    if (destCount < 15) {
      console.error(`FAIL: Destinations count is ${destCount}, expected at least 15.`);
      success = false;
    }

    // 2. Attractions per destination
    let totalAttractions = 0;
    for (const doc of destSnap.docs) {
      const destId = doc.id;
      const attrSnap = await adminDb.collection('destinations').doc(destId).collection('attractions').get();
      const count = attrSnap.size;
      totalAttractions += count;

      const minExpected = destId === 'hampi' ? 8 : 4;
      if (count < minExpected) {
        console.error(`FAIL: Destination '${destId}' has ${count} attractions, expected at least ${minExpected}.`);
        success = false;
      }
    }
    console.log(`- Total Attractions verified: ${totalAttractions}`);

    // 3. Phrases (expect >= 56)
    const phrasesSnap = await adminDb.collection('phrases').get();
    const phrasesCount = phrasesSnap.size;
    console.log(`- Phrases count: ${phrasesCount} (expected >= 56)`);
    if (phrasesCount < 56) {
      console.error(`FAIL: Phrases count is ${phrasesCount}, expected at least 56.`);
      success = false;
    }

    // 4. Transport (expect >= 15)
    const transportSnap = await adminDb.collection('transport').get();
    const transportCount = transportSnap.size;
    console.log(`- Transport count: ${transportCount} (expected >= 15)`);
    if (transportCount < 15) {
      console.error(`FAIL: Transport count is ${transportCount}, expected at least 15.`);
      success = false;
    }

    // 5. meta/seed
    const metaSnap = await adminDb.collection('meta').doc('seed').get();
    if (metaSnap.exists) {
      console.log(`- meta/seed document present. Version: ${metaSnap.data()?.version}, SeededAt: ${metaSnap.data()?.seededAt}`);
    } else {
      console.warn('- Notice: meta/seed document not found.');
    }

    if (success) {
      console.log('SUCCESS: All collections meet or exceed required seed thresholds!');
    } else {
      console.error('VERIFICATION FAILED: One or more collections fell below required thresholds.');
    }

    return success;
  } catch (err: any) {
    console.error('Verification error connecting to Firestore:', err.message);
    return false;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  verifySeed().then((pass) => {
    process.exit(pass ? 0 : 1);
  });
}
