import { Router, Request, Response } from 'express';
import { serverDb } from './db/database';
import {
  AgentOrchestrator,
  PlanContext,
  estimateTravelMinutes,
  computePlaceCrowdScore
} from '../shared/agents';
import { AssistantAgent } from '../shared/agents/assistant';
import { OfflineAgent } from '../shared/agents/offline';
import crypto from 'crypto';
import { runSeed } from './seed/seed';
import { Trip, TripDay, TripStop, User } from '../shared/types';

export const apiRouter = Router();

// 1. Current user
apiRouter.get('/user/current', (req: Request, res: Response) => {
  const user = Array.from(serverDb.users.values())[0];
  const profile = serverDb.profiles.get(user.id);
  res.json({ ...user, profile });
});

// 2. Login
apiRouter.post('/user/login', (req: Request, res: Response) => {
  const { phone, pin } = req.body;
  if (!phone || !pin) {
    return res.status(400).json({ error: 'Phone and PIN required' });
  }
  const phoneHash = Buffer.from(phone).toString('base64');
  const pinHash = Buffer.from(pin).toString('base64');

  let user = Array.from(serverDb.users.values()).find((u) => u.phone_hash === phoneHash);
  if (!user) {
    user = {
      id: `usr_${Date.now()}`,
      name: `Traveler ${phone.slice(-4)}`,
      phone_hash: phoneHash,
      pin_hash: pinHash,
      lang: 'en',
      created_at: new Date().toISOString()
    };
    serverDb.users.set(user.id, user);
  }
  res.json(user);
});

// 3. Config
apiRouter.get('/config', (req: Request, res: Response) => {
  res.json({
    regions: Array.from(serverDb.regions.values()),
    rules: serverDb.rules,
    emergency_numbers: serverDb.rules.emergency_numbers
  });
});

// 4. Generate Trip
apiRouter.post('/trips/generate', async (req: Request, res: Response) => {
  try {
    const parse = TripPlannerInputSchema.safeParse(req.body);
    if (!parse.success) {
      return res.status(400).json({ error: 'Invalid input', details: parse.error.issues });
    }
    const input = parse.data;
    const user = Array.from(serverDb.users.values())[0];
    const tripId = `trip_${Date.now()}`;

    const context: PlanContext = {
      tripId,
      userId: user.id,
      interests: input.interests,
      days: input.days,
      budget: input.budget,
      travelStyle: input.style,
      startCity: input.start_city,
      startDate: input.start_date,
      isWoman: input.is_woman,
      karnatakaDomicile: input.karnataka_domicile,
      lang: input.lang,
      allRegions: Array.from(serverDb.regions.values()),
      allPlaces: Array.from(serverDb.places.values()),
      allStays: Array.from(serverDb.stays.values()),
      allFoodSpots: Array.from(serverDb.foodSpots.values()),
      allTransportLegs: Array.from(serverDb.transportLegs.values()),
      rulesConfig: serverDb.rules
    };

    const orchestrator = new AgentOrchestrator(context);
    const result = await orchestrator.runPipeline();

    // Store trip & agent runs
    serverDb.trips.set(result.trip.id, result.trip);
    for (const run of result.agentRuns) {
      serverDb.agentRuns.push(run);
    }

    res.status(201).json(result.trip);
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Failed to generate trip' });
  }
});

// 5. Trips list
apiRouter.get('/trips', (req: Request, res: Response) => {
  res.json(Array.from(serverDb.trips.values()));
});

// 6. Single trip
apiRouter.get('/trips/:id', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  res.json(trip);
});

// 7. Update trip
apiRouter.patch('/trips/:id', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const updated = { ...trip, ...req.body };
  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 8. Toggle Shakti Scheme
apiRouter.post('/trips/:id/shakti', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { active } = req.body;
  const isWoman = trip.travel_style.includes('women') || trip.travel_style === 'solo';

  let totalTransport = 0;
  const days = trip.days.map((day) => {
    let travelLeg = day.travel_leg;
    if (travelLeg) {
      const eligible = active && isWoman && travelLeg.shakti_eligible;
      const effectiveFare = eligible ? 0 : travelLeg.original_fare_inr || travelLeg.fare_inr;
      travelLeg = {
        ...travelLeg,
        fare_inr: effectiveFare,
        shakti_applied: eligible,
        original_fare_inr: travelLeg.original_fare_inr || travelLeg.fare_inr
      };
      totalTransport += effectiveFare;
    }
    return { ...day, travel_leg: travelLeg };
  });

  const entryFees = days.flatMap((d) => d.stops).reduce((acc, s) => acc + (s.cost_inr || 0), 0);
  const stayCost = trip.days.length * 1500;
  const foodCost = trip.days.length * 500;
  const subtotal = entryFees + stayCost + foodCost + totalTransport;
  const buffer10 = Math.round(subtotal * 0.1);

  const updated: Trip = {
    ...trip,
    shakti_active: active,
    days,
    budget_breakdown: {
      stay_inr: stayCost,
      transport_inr: totalTransport,
      food_inr: foodCost,
      entry_fees_inr: entryFees,
      buffer_10pct_inr: buffer10,
      total_inr: subtotal + buffer10
    }
  };

  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 9. Swap stops
apiRouter.post('/trips/:id/stops/swap', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { stopId, direction } = req.body;

  let targetDayIndex = -1;
  let targetStopIndex = -1;

  trip.days.forEach((day, dIdx) => {
    const sIdx = day.stops.findIndex((s) => s.id === stopId);
    if (sIdx !== -1) {
      targetDayIndex = dIdx;
      targetStopIndex = sIdx;
    }
  });

  if (targetDayIndex === -1) return res.status(404).json({ error: 'Stop not found' });
  const day = { ...trip.days[targetDayIndex] };
  const stops = [...day.stops];
  const target = direction === 'up' ? targetStopIndex - 1 : targetStopIndex + 1;

  if (target >= 0 && target < stops.length) {
    const temp = stops[targetStopIndex];
    stops[targetStopIndex] = stops[target];
    stops[target] = temp;
    day.stops = stops;

    const newDays = [...trip.days];
    newDays[targetDayIndex] = day;
    const updated = { ...trip, days: newDays };
    serverDb.trips.set(trip.id, updated);
    return res.json(updated);
  }
  res.json(trip);
});

// 10. Remove stop
apiRouter.post('/trips/:id/stops/remove', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { stopId } = req.body;

  const newDays = trip.days.map((day) => ({
    ...day,
    stops: day.stops.filter((s) => s.id !== stopId)
  }));
  const updated = { ...trip, days: newDays };
  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 11. Toggle Lock stop
apiRouter.post('/trips/:id/stops/lock', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { stopId } = req.body;

  const newDays = trip.days.map((day) => ({
    ...day,
    stops: day.stops.map((s) => (s.id === stopId ? { ...s, is_locked: !s.is_locked } : s))
  }));
  const updated = { ...trip, days: newDays };
  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 12. Accept quiet alternative
apiRouter.post('/trips/:id/stops/quiet-alt', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { stopId } = req.body;

  let quietTargetStop: TripStop | null = null;
  for (const day of trip.days) {
    const found = day.stops.find((s) => s.id === stopId);
    if (found?.quiet_alternative) {
      quietTargetStop = found;
      break;
    }
  }

  if (!quietTargetStop || !quietTargetStop.quiet_alternative) {
    return res.status(400).json({ error: 'No quiet alternative available' });
  }

  const alt = quietTargetStop.quiet_alternative;
  const altPlace = serverDb.places.get(alt.place_id);

  const newDays = trip.days.map((day) => ({
    ...day,
    stops: day.stops.map((s) => {
      if (s.id === stopId) {
        return {
          ...s,
          place_id: alt.place_id,
          place_name_i18n: altPlace?.name_i18n || s.place_name_i18n,
          crowd_level: alt.expected_crowd,
          cost_inr: altPlace?.entry_fee_inr ?? s.cost_inr,
          reason: alt.reason,
          quiet_alternative: undefined
        };
      }
      return s;
    })
  }));

  const updated = { ...trip, days: newDays };
  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 13. Plan B routes
apiRouter.post('/trips/:id/planb/generate', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { trigger } = req.body;

  const weatherCard = {
    place: 'Hampi Heritage Valley',
    date: '2026-10-25',
    condition: trigger === 'rain' ? 'Rain' : trigger === 'heat' ? 'High Heat' : 'Operational disruption',
    temperature_c: trigger === 'heat' ? 38 : 27,
    message:
      trigger === 'rain'
        ? 'Heavy rain forecast. Shifting to indoor temple museums and covered pavilions.'
        : trigger === 'heat'
        ? 'Peak afternoon heat warning. Shifting afternoon outdoor walks to morning/evening.'
        : 'Transit disruption. Re-routing to local cluster attractions.'
  };

  const suggestedChanges = [
    {
      id: 'chg_1',
      title: 'Visit Archaeological Museum inside Kamalapura instead of exposed boulders',
      type: 'substitute',
      from_stop_id: 'stop_1',
      to_place_id: 'pl_hampi_museum',
      reason: 'Air-conditioned galleries and covered exhibits'
    },
    {
      id: 'chg_2',
      title: 'Move riverside walk to early morning slot (07:00 AM)',
      type: 'reschedule',
      from_stop_id: 'stop_2',
      reason: 'Cool morning temperature and clear visibility'
    }
  ];

  res.json({ weatherCard, suggestedChanges });
});

apiRouter.post('/trips/:id/planb/apply', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const { trigger } = req.body;

  const updated: Trip = {
    ...trip,
    active_plan_b: trigger,
    days: trip.days.map((day) => ({
      ...day,
      stops: day.stops.map((stop) => {
        if (!stop.is_locked && stop.quiet_alternative) {
          const altPlace = serverDb.places.get(stop.quiet_alternative.place_id);
          return {
            ...stop,
            place_id: stop.quiet_alternative.place_id,
            place_name_i18n: altPlace?.name_i18n || stop.place_name_i18n,
            reason: `[Plan B: ${trigger}] Shifted to covered alternative`
          };
        }
        return stop;
      })
    }))
  };

  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

apiRouter.post('/trips/:id/planb/revert', (req: Request, res: Response) => {
  const trip = serverDb.trips.get(req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  const updated = { ...trip, active_plan_b: undefined };
  serverDb.trips.set(trip.id, updated);
  res.json(updated);
});

// 14. Places
apiRouter.get('/places', (req: Request, res: Response) => {
  const { q, category } = req.query;
  let list = Array.from(serverDb.places.values());

  if (category && category !== 'all') {
    list = list.filter((p) => p.category === category);
  }

  if (q && typeof q === 'string' && q.trim()) {
    const term = q.toLowerCase();
    list = list.filter(
      (p) =>
        p.name_i18n.en.toLowerCase().includes(term) ||
        p.name_i18n.kn.toLowerCase().includes(term) ||
        p.name_i18n.mr.toLowerCase().includes(term) ||
        p.description_i18n.en.toLowerCase().includes(term)
    );
  }

  const enhanced = list.map((p) => {
    const altPlace = p.quiet_alternative_id ? serverDb.places.get(p.quiet_alternative_id) : null;
    const isSaved = serverDb.savedPlaces.has(p.id);
    return {
      ...p,
      is_bookmarked: isSaved,
      distance_km: Math.round(1.5 + (p.lat % 1) * 8 * 10) / 10,
      travel_minutes: Math.round(5 + (p.lng % 1) * 20),
      quiet_alt_place: altPlace
    };
  });

  res.json(enhanced);
});

apiRouter.get('/places/:id', (req: Request, res: Response) => {
  const place = serverDb.places.get(req.params.id);
  if (!place) return res.status(404).json({ error: 'Place not found' });
  const altPlace = place.quiet_alternative_id ? serverDb.places.get(place.quiet_alternative_id) : null;
  res.json({
    ...place,
    is_bookmarked: serverDb.savedPlaces.has(place.id),
    quiet_alt_place: altPlace
  });
});

// 15. Bookmark toggle
apiRouter.post('/places/:id/bookmark', (req: Request, res: Response) => {
  const placeId = req.params.id;
  const user = Array.from(serverDb.users.values())[0];
  if (serverDb.savedPlaces.has(placeId)) {
    serverDb.savedPlaces.delete(placeId);
    return res.json({ bookmarked: false });
  } else {
    serverDb.savedPlaces.set(placeId, {
      id: `saved_${Date.now()}`,
      user_id: user.id,
      place_id: placeId,
      saved_at: new Date().toISOString()
    });
    return res.json({ bookmarked: true });
  }
});

// 16. Saved items
apiRouter.get('/saved', (req: Request, res: Response) => {
  const trips = Array.from(serverDb.trips.values());
  const savedIds = Array.from(serverDb.savedPlaces.keys());
  const places = savedIds.map((id) => serverDb.places.get(id)).filter(Boolean);
  res.json({ trips, places });
});

// 17. Offline pack
apiRouter.post('/offline/pack', async (req: Request, res: Response) => {
  const { tripId } = req.body;
  const trip = serverDb.trips.get(tripId);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });

  const places = Array.from(serverDb.places.values());
  const legs = Array.from(serverDb.transportLegs.values());
  const pack = OfflineAgent.bundleTripOffline(trip, places, legs, serverDb.rules);
  serverDb.offlinePacks.set(tripId, pack);
  res.json(pack);
});

// 18. Assistant
apiRouter.post('/assistant/ask', (req: Request, res: Response) => {
  const { query, tripId, lang = 'en' } = req.body;
  const trip = tripId ? serverDb.trips.get(tripId) : undefined;
  const places = Array.from(serverDb.places.values());
  const answer = AssistantAgent.answerUserQuery(query, trip, places, serverDb.rules, lang);
  res.json(answer);
});

// 19. Agent runs
apiRouter.get('/agent-runs/:tripId', (req: Request, res: Response) => {
  const runs = serverDb.agentRuns.filter((r) => r.trip_id === req.params.tripId);
  res.json(runs);
});

// 20. Transport legs
apiRouter.get('/transport-legs', (req: Request, res: Response) => {
  res.json(Array.from(serverDb.transportLegs.values()));
});

// 21. Emergency contacts
apiRouter.get('/emergency-contacts', (req: Request, res: Response) => {
  res.json(Array.from(serverDb.emergencyContacts.values()));
});

apiRouter.post('/emergency-contacts', (req: Request, res: Response) => {
  const { name, phone } = req.body;
  const user = Array.from(serverDb.users.values())[0];
  const newContact = {
    id: `emg_${Date.now()}`,
    user_id: user.id,
    name,
    phone
  };
  serverDb.emergencyContacts.set(newContact.id, newContact);
  res.status(201).json(newContact);
});

// 22. Protected Seed Endpoint (Server-only, constant-time secret check, 404 otherwise)
apiRouter.post('/admin/seed', async (req: Request, res: Response) => {
  const seedEnabled = process.env.SEED_ENABLED === 'true';
  const configuredSecret = process.env.SEED_SECRET || '';
  const incomingSecret = (req.headers['x-seed-secret'] as string) || '';

  if (!seedEnabled || !configuredSecret || !incomingSecret) {
    return res.status(404).json({ error: 'Not found' });
  }

  const bufConfigured = Buffer.from(configuredSecret);
  const bufIncoming = Buffer.from(incomingSecret);

  if (bufConfigured.length !== bufIncoming.length || !crypto.timingSafeEqual(bufConfigured, bufIncoming)) {
    return res.status(404).json({ error: 'Not found' });
  }

  try {
    const stats = await runSeed();
    return res.json({ ok: true, stats });
  } catch (err: any) {
    console.error('Seed endpoint error:', err);
    return res.status(500).json({ error: 'Seeding failed', details: err?.message });
  }
});
