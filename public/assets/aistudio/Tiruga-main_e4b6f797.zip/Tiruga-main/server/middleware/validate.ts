import { Request, Response, NextFunction } from 'express';

/**
 * Strips control characters (except common whitespace: \n, \r, \t) and trims string.
 * Optionally truncates to max length.
 */
export function sanitizeText(s: unknown, max?: number): string {
  if (typeof s !== 'string') return '';
  // Remove ASCII control chars (0x00-0x08, 0x0B, 0x0C, 0x0E-0x1F, 0x7F) and Unicode control codes
  let cleaned = s.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F\u0080-\u009F]/g, '').trim();
  if (max !== undefined && max > 0 && cleaned.length > max) {
    cleaned = cleaned.slice(0, max);
  }
  return cleaned;
}

/**
 * Middleware ensuring JSON content-type for request bodies.
 */
export function requireJsonContent(req: Request, res: Response, next: NextFunction): void {
  if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
    const contentType = req.headers['content-type'] || '';
    if (!contentType.toLowerCase().includes('application/json')) {
      res.status(400).json({
        ok: false,
        error: {
          code: 'INVALID_INPUT',
          message: 'Content-Type must be application/json.'
        }
      });
      return;
    }
  }
  next();
}

/**
 * Validation error response helper
 */
export function sendValidationError(res: Response, message: string): void {
  res.status(400).json({
    ok: false,
    error: {
      code: 'INVALID_INPUT',
      message
    }
  });
}

/**
 * Input validator for AI planning routes
 */
export function validatePlanInput(req: Request, res: Response, next: NextFunction): void {
  const body = req.body;
  if (!body || typeof body !== 'object') {
    return sendValidationError(res, 'Request body must be a valid JSON object.');
  }

  // Allowed fields for planning request
  const allowedFields = new Set([
    'destination',
    'destinationId',
    'days',
    'totalDays',
    'budget',
    'estimatedBudget',
    'travellerType',
    'travelStyle',
    'interests',
    'preferences'
  ]);

  for (const key of Object.keys(body)) {
    if (!allowedFields.has(key)) {
      return sendValidationError(res, `Unknown field '${key}' in request.`);
    }
  }

  // Validate days: 1 to 7
  const rawDays = body.days !== undefined ? body.days : body.totalDays;
  const days = Number(rawDays);
  if (isNaN(days) || days < 1 || days > 7) {
    return sendValidationError(res, 'Trip duration (days) must be an integer between 1 and 7.');
  }

  // Validate budget
  if (body.budget !== undefined || body.estimatedBudget !== undefined) {
    const budget = Number(body.budget || body.estimatedBudget);
    if (isNaN(budget) || budget <= 0 || budget > 500000) {
      return sendValidationError(res, 'Budget must be a positive number under ₹5,00,000.');
    }
  }

  // Sanitize strings and check length <= 500
  if (body.destination && typeof body.destination === 'string') {
    if (body.destination.length > 500) {
      return sendValidationError(res, 'Destination name exceeds maximum length of 500 characters.');
    }
    body.destination = sanitizeText(body.destination, 500);
  }

  if (body.travelStyle && typeof body.travelStyle === 'string') {
    if (body.travelStyle.length > 500) {
      return sendValidationError(res, 'Travel style string exceeds 500 characters.');
    }
    body.travelStyle = sanitizeText(body.travelStyle, 500);
  }

  if (body.travellerType && typeof body.travellerType === 'string') {
    body.travellerType = sanitizeText(body.travellerType, 500);
  }

  // Validate interests array
  if (body.interests) {
    if (!Array.isArray(body.interests)) {
      return sendValidationError(res, 'Interests must be an array of strings.');
    }
    if (body.interests.length > 10) {
      return sendValidationError(res, 'A maximum of 10 interests can be selected.');
    }
    body.interests = body.interests.map((i: unknown) => sanitizeText(i, 100));
  }

  next();
}

/**
 * Validator for Ask About Place
 */
export function validateAskPlaceInput(req: Request, res: Response, next: NextFunction): void {
  const { placeName, question } = req.body || {};
  if (!placeName || typeof placeName !== 'string') {
    return sendValidationError(res, 'placeName is required and must be a string.');
  }
  if (!question || typeof question !== 'string') {
    return sendValidationError(res, 'question is required and must be a string.');
  }

  if (placeName.length > 500 || question.length > 500) {
    return sendValidationError(res, 'Inputs must not exceed 500 characters.');
  }

  req.body.placeName = sanitizeText(placeName, 500);
  req.body.question = sanitizeText(question, 500);
  next();
}

/**
 * Validator for Modify Trip
 */
export function validateModifyTripInput(req: Request, res: Response, next: NextFunction): void {
  const { instruction, trip } = req.body || {};
  if (!instruction || typeof instruction !== 'string') {
    return sendValidationError(res, 'instruction is required and must be a string.');
  }
  if (instruction.length > 500) {
    return sendValidationError(res, 'Instruction must not exceed 500 characters.');
  }
  if (trip && typeof trip === 'object') {
    if (Array.isArray(trip.days) && trip.days.length > 7) {
      return sendValidationError(res, 'Trip cannot exceed 7 days.');
    }
  }

  req.body.instruction = sanitizeText(instruction, 500);
  next();
}
