import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../firebaseAdmin';

export interface AuthenticatedUser {
  uid: string;
  email?: string;
}

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser | null;
    }
  }
}

/**
 * Extracts Bearer token from Authorization header.
 * Never logs or exposes token.
 */
function extractBearerToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice(7).trim();
  return token || null;
}

/**
 * optionalAuth middleware:
 * If Authorization header is present, verifies ID token.
 * If token is valid, attaches req.user = { uid, email }.
 * If token is missing, req.user = null (guest mode).
 * If token is present but expired / invalid, returns 401.
 */
export async function optionalAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const token = extractBearerToken(req);

  if (!token) {
    req.user = null;
    return next();
  }

  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.user = {
      uid: decoded.uid,
      email: decoded.email
    };
    next();
  } catch (err: any) {
    res.status(401).json({
      ok: false,
      error: {
        code: 'UNAUTHENTICATED',
        message: 'Please sign in again.'
      }
    });
  }
}

/**
 * requireAuth middleware:
 * Requires a valid Firebase ID token.
 * Returns 401 if missing, invalid, or expired.
 */
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const token = extractBearerToken(req);

  if (!token) {
    res.status(401).json({
      ok: false,
      error: {
        code: 'UNAUTHENTICATED',
        message: 'Please sign in again.'
      }
    });
    return;
  }

  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.user = {
      uid: decoded.uid,
      email: decoded.email
    };
    next();
  } catch (err: any) {
    res.status(401).json({
      ok: false,
      error: {
        code: 'UNAUTHENTICATED',
        message: 'Please sign in again.'
      }
    });
  }
}
