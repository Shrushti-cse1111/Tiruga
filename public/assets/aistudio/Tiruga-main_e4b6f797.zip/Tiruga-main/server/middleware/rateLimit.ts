import { Request, Response, NextFunction } from 'express';

export interface RateLimitOptions {
  windowMs: number;
  max: number;
  keyFn: (req: Request) => string;
  message?: string;
}

interface WindowBucket {
  timestamps: number[];
}

/**
 * Factory for in-memory sliding-window rate limiters.
 */
export function createLimiter(options: RateLimitOptions) {
  const { windowMs, max, keyFn, message = 'Too many requests. Please slow down and try again.' } = options;
  const store = new Map<string, WindowBucket>();

  // Periodic cleanup so memory does not grow
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [key, bucket] of store.entries()) {
      bucket.timestamps = bucket.timestamps.filter((ts) => now - ts < windowMs);
      if (bucket.timestamps.length === 0) {
        store.delete(key);
      }
    }
  }, Math.max(windowMs, 30000));

  // Allow Node process to exit cleanly without waiting for this interval
  if (cleanupInterval.unref) {
    cleanupInterval.unref();
  }

  return (req: Request, res: Response, next: NextFunction): void => {
    const key = keyFn(req);
    if (!key) {
      return next();
    }

    const now = Date.now();
    let bucket = store.get(key);
    if (!bucket) {
      bucket = { timestamps: [] };
      store.set(key, bucket);
    }

    // Filter timestamps within the current window
    bucket.timestamps = bucket.timestamps.filter((ts) => now - ts < windowMs);

    if (bucket.timestamps.length >= max) {
      const oldest = bucket.timestamps[0];
      const resetTimeMs = oldest + windowMs - now;
      const retryAfterSec = Math.max(1, Math.ceil(resetTimeMs / 1000));

      res.setHeader('Retry-After', retryAfterSec.toString());
      res.setHeader('X-RateLimit-Limit', max.toString());
      res.setHeader('X-RateLimit-Remaining', '0');
      res.setHeader('X-RateLimit-Reset', Math.ceil((oldest + windowMs) / 1000).toString());

      res.status(429).json({
        ok: false,
        error: {
          code: 'RATE_LIMITED',
          message: `${message} Retry after ${retryAfterSec}s.`,
          retryable: true
        }
      });
      return;
    }

    bucket.timestamps.push(now);
    res.setHeader('X-RateLimit-Limit', max.toString());
    res.setHeader('X-RateLimit-Remaining', (max - bucket.timestamps.length).toString());

    next();
  };
}

// Helpers for IP and UID extraction
export const getClientIp = (req: Request): string => {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || 'unknown-ip';
};

export const getUserOrIp = (req: Request): string => {
  const user = (req as any).user;
  return user?.uid || getClientIp(req);
};

// Preset limiters
export const rateLimiters = {
  // 8 requests/minute per IP
  aiGuest: createLimiter({
    windowMs: 60 * 1000,
    max: 8,
    keyFn: (req) => `guest_ai:${getClientIp(req)}`,
    message: 'Guest AI rate limit exceeded (8 requests/min).'
  }),

  // 20 requests/minute per uid
  aiUser: createLimiter({
    windowMs: 60 * 1000,
    max: 20,
    keyFn: (req) => {
      const user = (req as any).user;
      return user?.uid ? `user_ai:${user.uid}` : `guest_ai:${getClientIp(req)}`;
    },
    message: 'Account AI rate limit exceeded (20 requests/min).'
  }),

  // 120 requests/minute per IP
  general: createLimiter({
    windowMs: 60 * 1000,
    max: 120,
    keyFn: (req) => `general:${getClientIp(req)}`,
    message: 'Too many requests. Please wait a moment.'
  }),

  // 3 requests/hour per IP
  seed: createLimiter({
    windowMs: 60 * 60 * 1000,
    max: 3,
    keyFn: (req) => `seed:${getClientIp(req)}`,
    message: 'Seed rate limit exceeded (3 requests/hour).'
  })
};

/**
 * Dynamic limiter that routes authenticated users to aiUser and guests to aiGuest.
 */
export function dynamicAiLimiter(req: Request, res: Response, next: NextFunction): void {
  const user = (req as any).user;
  if (user?.uid) {
    return rateLimiters.aiUser(req, res, next);
  }
  return rateLimiters.aiGuest(req, res, next);
}
