import { Request, Response, NextFunction } from 'express';

/**
 * 404 handler for unknown /api routes.
 * Always returns clean structured JSON.
 */
export function apiNotFoundHandler(req: Request, res: Response, next: NextFunction): void {
  if (req.path.startsWith('/api')) {
    res.status(404).json({
      ok: false,
      error: {
        code: 'NOT_FOUND',
        message: `Endpoint ${req.method} ${req.path} not found.`
      }
    });
    return;
  }
  next();
}

/**
 * Global error handler.
 * Never leaks stack traces, environment variables, or secret parameters.
 */
export function globalErrorHandler(
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Safe server-side error logging
  const route = req.originalUrl || req.url;
  const status = typeof err.status === 'number' && err.status >= 400 && err.status < 600 ? err.status : 500;
  const code = err.code || (status === 400 ? 'INVALID_INPUT' : 'INTERNAL_SERVER_ERROR');
  const message = status === 500 ? 'An internal server error occurred.' : (err.message || 'Request failed.');

  console.error(`[Server Error] [${req.method} ${route}] Status ${status} - Code ${code}`);

  res.status(status).json({
    ok: false,
    error: {
      code,
      message
    }
  });
}
