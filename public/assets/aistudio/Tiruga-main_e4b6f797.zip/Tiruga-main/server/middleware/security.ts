import { Request, Response, NextFunction } from 'express';
import { config } from '../config';

/**
 * Custom security headers middleware (Zero extra libraries).
 */
export function securityHeaders(req: Request, res: Response, next: NextFunction): void {
  // 1. Remove X-Powered-By
  res.removeHeader('X-Powered-By');

  // 2. Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // 3. Referrer Policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // 4. Permissions Policy limiting hardware access
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(self)');

  // 5. Frame Options (Allow in dev for AI Studio iframe preview, SAMEORIGIN in prod)
  if (config.nodeEnv === 'production') {
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  } else {
    // In dev, omit X-Frame-Options or allow iframe preview from parent AI Studio
    res.setHeader('X-Frame-Options', 'ALLOWALL');
  }

  // 6. Content-Security-Policy
  const cspDirectives = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com https://*.firebaseapp.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: https: blob:",
    "connect-src 'self' https://*.googleapis.com https://*.firebaseio.com https://*.firebaseapp.com https://accounts.google.com https://identitytoolkit.googleapis.com",
    "frame-src 'self' https://*.firebaseapp.com https://accounts.google.com",
    "object-src 'none'",
    "base-uri 'self'"
  ];
  res.setHeader('Content-Security-Policy', cspDirectives.join('; '));

  // 7. CORS: Same-origin by default, or specific origins from config.allowedOrigins
  const origin = req.headers.origin;
  if (origin && config.allowedOrigins.length > 0) {
    if (config.allowedOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Seed-Secret');
      res.setHeader('Access-Control-Allow-Credentials', 'true');
    }
  }

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  next();
}
