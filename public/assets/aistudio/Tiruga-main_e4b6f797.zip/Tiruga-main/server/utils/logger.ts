import { Request, Response, NextFunction } from 'express';

export interface StructuredLog {
  timestamp: string;
  method: string;
  route: string;
  status: number;
  latencyMs: number;
  uid: string;
  ip: string;
}

/**
 * Safe request logger middleware.
 * Never logs authorization tokens, API keys, request bodies, or user prompts.
 */
export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  const start = Date.now();
  const route = req.originalUrl || req.url;

  // Intercept response finish
  res.on('finish', () => {
    // Skip static assets and HMR in development to prevent noisy logs
    if (
      route.startsWith('/@') ||
      route.startsWith('/src/') ||
      route.startsWith('/node_modules/') ||
      route.endsWith('.js') ||
      route.endsWith('.css') ||
      route.endsWith('.svg') ||
      route.endsWith('.png') ||
      route.endsWith('.ico')
    ) {
      return;
    }

    const latencyMs = Date.now() - start;
    const uid = (req as any).user?.uid || 'guest';
    const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.ip || 'unknown';

    const logEntry: StructuredLog = {
      timestamp: new Date().toISOString(),
      method: req.method,
      route,
      status: res.statusCode,
      latencyMs,
      uid,
      ip: clientIp
    };

    if (res.statusCode >= 500) {
      console.error(JSON.stringify({ level: 'ERROR', ...logEntry }));
    } else if (res.statusCode >= 400) {
      console.warn(JSON.stringify({ level: 'WARN', ...logEntry }));
    } else {
      console.log(JSON.stringify({ level: 'INFO', ...logEntry }));
    }
  });

  next();
}
