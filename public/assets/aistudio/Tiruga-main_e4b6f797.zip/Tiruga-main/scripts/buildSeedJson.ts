import fs from 'fs';
import path from 'path';
import { SEED_REGIONS, SEED_INTERESTS, SEED_RULES_CONFIG, TODAY } from '../shared/data/seedData';
import {
  SEED_PLACES,
  SEED_STAYS,
  SEED_FOOD_SPOTS,
  SEED_TRANSPORT_LEGS,
  SEED_ALTERNATIVES,
  SEED_PLACE_HOURS
} from '../shared/data/seedPlaces';

const SEED_DIR = path.resolve('shared/seed');
if (!fs.existsSync(SEED_DIR)) {
  fs.mkdirSync(SEED_DIR, { recursive: true });
}

// 1. Regions with 12 months climatology
const climatologies: Record<string, Array<{ rainProb: number; tempMin: number; tempMax: number; sunset: string }>> = {
  'reg_hampi': [
    { rainProb: 2, tempMin: 18, tempMax: 31, sunset: '18:10' },
    { rainProb: 3, tempMin: 20, tempMax: 34, sunset: '18:22' },
    { rainProb: 5, tempMin: 23, tempMax: 37, sunset: '18:31' },
    { rainProb: 15, tempMin: 26, tempMax: 39, sunset: '18:38' },
    { rainProb: 30, tempMin: 26, tempMax: 38, sunset: '18:47' },
    { rainProb: 60, tempMin: 24, tempMax: 33, sunset: '18:56' },
    { rainProb: 75, tempMin: 23, tempMax: 31, sunset: '18:58' },
    { rainProb: 70, tempMin: 23, tempMax: 30, sunset: '18:49' },
    { rainProb: 65, tempMin: 22, tempMax: 31, sunset: '18:30' },
    { rainProb: 35, tempMin: 21, tempMax: 32, sunset: '18:10' },
    { rainProb: 10, tempMin: 19, tempMax: 31, sunset: '17:58' },
    { rainProb: 4, tempMin: 17, tempMax: 30, sunset: '18:00' }
  ],
  'reg_mysuru': [
    { rainProb: 4, tempMin: 17, tempMax: 30, sunset: '18:14' },
    { rainProb: 5, tempMin: 18, tempMax: 32, sunset: '18:25' },
    { rainProb: 12, tempMin: 20, tempMax: 34, sunset: '18:31' },
    { rainProb: 35, tempMin: 21, tempMax: 34, sunset: '18:34' },
    { rainProb: 55, tempMin: 21, tempMax: 32, sunset: '18:41' },
    { rainProb: 65, tempMin: 20, tempMax: 29, sunset: '18:49' },
    { rainProb: 75, tempMin: 20, tempMax: 28, sunset: '18:52' },
    { rainProb: 70, tempMin: 20, tempMax: 28, sunset: '18:45' },
    { rainProb: 65, tempMin: 20, tempMax: 29, sunset: '18:29' },
    { rainProb: 60, tempMin: 20, tempMax: 30, sunset: '18:11' },
    { rainProb: 30, tempMin: 18, tempMax: 29, sunset: '18:00' },
    { rainProb: 10, tempMin: 16, tempMax: 29, sunset: '18:03' }
  ]
};

const defaultClim = climatologies['reg_hampi'];

const regions = SEED_REGIONS.map(r => ({
  id: r.id,
  slug: r.slug,
  name: r.name_i18n,
  centerLat: r.center_lat,
  centerLng: r.center_lng,
  climatology: climatologies[r.id] || defaultClim
}));
fs.writeFileSync(path.join(SEED_DIR, 'regions.json'), JSON.stringify(regions, null, 2));

// 2. Interests
const interests = SEED_INTERESTS.map(i => ({
  id: i.id,
  slug: i.slug,
  name: i.name_i18n,
  icon: i.icon
}));
fs.writeFileSync(path.join(SEED_DIR, 'interests.json'), JSON.stringify(interests, null, 2));

// 3. Category mapping helper
function mapCategory(cat: string): 'temple' | 'ruin' | 'museum' | 'viewpoint' | 'waterfall' | 'beach' | 'market' | 'cafe' | 'food' {
  switch (cat) {
    case 'spiritual': return 'temple';
    case 'heritage': return 'ruin';
    case 'museum': return 'museum';
    case 'viewpoint': return 'viewpoint';
    case 'nature': return 'waterfall';
    case 'beach': return 'beach';
    case 'food': return 'cafe';
    default: return 'temple';
  }
}

// Map alternatives by place_id
const altMap = new Map<string, Array<{ placeId: string; similarity: number; tradeOff: any }>>();
SEED_ALTERNATIVES.forEach(a => {
  if (!altMap.has(a.place_id)) altMap.set(a.place_id, []);
  altMap.get(a.place_id)!.push({
    placeId: a.alt_place_id,
    similarity: a.similarity,
    tradeOff: a.trade_off_i18n
  });
});

// Map hours by place_id
const hoursMap = new Map<string, Record<string, { opens: string; closes: string; closed: boolean }>>();
SEED_PLACE_HOURS.forEach(h => {
  if (!hoursMap.has(h.place_id)) hoursMap.set(h.place_id, {});
  hoursMap.get(h.place_id)![String(h.weekday)] = {
    opens: h.opens,
    closes: h.closes,
    closed: h.closed
  };
});

const defaultHours: Record<string, { opens: string; closes: string; closed: boolean }> = {
  "0": { opens: "06:00", closes: "18:00", closed: false },
  "1": { opens: "06:00", closes: "18:00", closed: false },
  "2": { opens: "06:00", closes: "18:00", closed: false },
  "3": { opens: "06:00", closes: "18:00", closed: false },
  "4": { opens: "06:00", closes: "18:00", closed: false },
  "5": { opens: "06:00", closes: "18:00", closed: false },
  "6": { opens: "06:00", closes: "18:00", closed: false }
};

// 4. Places (>= 50 places)
const places = SEED_PLACES.map(p => {
  return {
    id: p.id,
    regionId: p.region_id,
    category: mapCategory(p.category),
    name: p.name_i18n,
    summary: p.summary_i18n,
    whyVisit: p.why_visit_i18n,
    lat: p.lat,
    lng: p.lng,
    interestTags: [
      { interestId: 'int_' + (p.category === 'spiritual' ? 'spiritual' : p.category === 'nature' ? 'nature' : 'heritage'), weight: 1.0 },
      { interestId: 'int_food', weight: 0.3 }
    ],
    entryFeeInr: p.entry_fee_inr,
    avgVisitMin: p.avg_visit_min,
    bestMonths: p.best_months,
    isOutdoor: p.is_outdoor,
    isIndoorAlt: p.is_indoor_alt,
    seniorFriendly: p.senior_friendly,
    dressCode: p.dress_code_i18n,
    rules: p.rules_i18n,
    hasToilet: p.has_toilet,
    hasWater: p.has_water,
    hasShade: p.has_shade,
    localBenefit: p.local_benefit,
    rating: p.rating,
    imageHint: p.image_hint,
    hours: hoursMap.get(p.id) || defaultHours,
    crowd: {
      baseline: p.is_outdoor ? 65 : 45,
      monthMultiplier: [1.0, 1.0, 1.1, 1.2, 0.9, 0.8, 0.8, 0.9, 1.0, 1.2, 1.3, 1.4],
      weekdayMultiplier: [1.3, 0.9, 0.9, 0.9, 0.9, 1.1, 1.4],
      hourCurve: [
        10, 10, 10, 10, 10, 15, 25, 40, 60, 75,
        85, 90, 80, 70, 75, 85, 95, 90, 70, 50,
        30, 20, 10, 10
      ]
    },
    alternatives: altMap.get(p.id) || [],
    source: p.source || 'Sample data: Karnataka Tourism & Gazetteer',
    lastChecked: p.last_checked || TODAY,
    verified: false
  };
});
fs.writeFileSync(path.join(SEED_DIR, 'places.json'), JSON.stringify(places, null, 2));

// 5. Stays (30 stays)
const stays = SEED_STAYS.map(s => ({
  id: s.id,
  regionId: s.region_id,
  name: s.name_i18n,
  lat: s.lat,
  lng: s.lng,
  pricePerNightInr: s.price_per_night_inr,
  registrationStatus: s.registration_status,
  registrationNo: s.registration_status === 'registered' ? `KSTDC-REG-${s.id.slice(4, 10).toUpperCase()}` : null,
  source: s.source || 'Sample data: Local Tourism Registry',
  lastChecked: s.last_checked || TODAY
}));
fs.writeFileSync(path.join(SEED_DIR, 'stays.json'), JSON.stringify(stays, null, 2));

// 6. Food Spots (40 food spots)
const foodSpots = SEED_FOOD_SPOTS.map(f => ({
  id: f.id,
  regionId: f.region_id,
  placeId: f.place_id || null,
  name: f.name_i18n,
  dish: f.dish_i18n,
  veg: f.veg,
  avgCostInr: f.avg_cost_inr,
  lat: f.lat,
  lng: f.lng,
  source: 'Sample data: Local Culinary Association',
  lastChecked: TODAY
}));
fs.writeFileSync(path.join(SEED_DIR, 'foodSpots.json'), JSON.stringify(foodSpots, null, 2));

// 7. Transport Legs (20 transport legs)
const transportLegs = SEED_TRANSPORT_LEGS.map(t => ({
  id: t.id,
  fromName: t.from_name,
  toName: t.to_name,
  mode: t.mode,
  operator: t.operator,
  serviceClass: t.service_class,
  depart: t.depart,
  arrive: t.arrive,
  durationMin: t.duration_min,
  stops: t.stops,
  runsOn: [t.runs_on || 'Daily'],
  fareInr: t.fare_inr,
  shaktiEligible: t.shakti_eligible,
  lastBus: t.last_bus,
  bookingUrl: t.booking_url,
  source: t.source || 'Sample data: KSRTC & Indian Railways',
  lastChecked: t.last_checked || TODAY,
  verified: false
}));
fs.writeFileSync(path.join(SEED_DIR, 'transportLegs.json'), JSON.stringify(transportLegs, null, 2));

// 8. Events Closures
const eventsClosures = [
  {
    id: 'evt_hampi_utsav',
    regionId: 'reg_hampi',
    placeId: 'plc_virupaksha',
    kind: 'festival',
    title: {
      en: 'Hampi Utsav Cultural Gathering',
      kn: 'ಹಂಪಿ ಉತ್ಸವ ಸಾಂಸ್ಕೃತಿಕ ಸಮ್ಮಿಲನ',
      mr: 'हंपी उत्सव सांस्कृतिक सोहळा'
    },
    startsOn: '2026-11-03',
    endsOn: '2026-11-05',
    crowdMultiplier: 1.8,
    closed: false
  },
  {
    id: 'evt_mysore_dasara',
    regionId: 'reg_mysuru',
    placeId: 'plc_mysuru_palace',
    kind: 'festival',
    title: {
      en: 'Mysuru Dasara Jumboo Savari',
      kn: 'ಮೈಸೂರು ದಸರಾ ಜಂಬೂ ಸವಾರಿ',
      mr: 'म्हैसूर दसरा जंबो सवारी'
    },
    startsOn: '2026-10-20',
    endsOn: '2026-10-24',
    crowdMultiplier: 2.5,
    closed: false
  },
  {
    id: 'evt_jog_monsoon_maintenance',
    regionId: 'reg_coast',
    placeId: 'plc_st_marys_island',
    kind: 'weather',
    title: {
      en: 'Monsoon Ferry Restrictions',
      kn: 'ಮಳೆಗಾಲದ ಬೋಟ್ ನಿರ್ಬಂಧಗಳು',
      mr: 'पावसाळी बोट सेवा निर्बंध'
    },
    startsOn: '2026-06-01',
    endsOn: '2026-09-30',
    crowdMultiplier: 0.1,
    closed: true
  }
];
fs.writeFileSync(path.join(SEED_DIR, 'eventsClosures.json'), JSON.stringify(eventsClosures, null, 2));

// 9. Rules Config documents
const rulesConfig: Record<string, any> = {
  shakti: {
    eligibleClasses: ['non_ac', 'ordinary', 'express'],
    domicileRequired: true,
    proofReminder: 'Carry Karnataka address proof ID (Aadhaar / Voter ID)',
    note: 'Confirm current rules on the bus'
  },
  scoringWeights: {
    interestAffinity: 0.4,
    crowdPenalty: 0.25,
    timeEfficiency: 0.2,
    rating: 0.15
  },
  styleModifiers: {
    solo: { crowdTolerance: 0.6 },
    senior: { minSeniorFriendly: 4, pace: 'relaxed' },
    women_group: { duskSafety: true }
  },
  thresholds: {
    crowd: 70
  },
  stopsPerDay: {
    relaxed: 3,
    balanced: 4,
    packed: 5
  },
  emergencyNumbers: [
    { label: 'Police', number: '112', note: 'verify' },
    { label: 'Ambulance', number: '108', note: 'verify' },
    { label: 'Women Helpline', number: '181', note: 'verify' },
    { label: 'Karnataka Tourist Helpline', number: '1800-425-2425', note: 'verify' }
  ],
  tips: {
    sunsetGoldenHour: "Hemakuta Hill and Raja's Seat get golden light between 17:15 and 17:50.",
    templeBlessings: "Temple elephant blessings start at 8:30 AM at Virupaksha Temple."
  }
};
fs.writeFileSync(path.join(SEED_DIR, 'rulesConfig.json'), JSON.stringify(rulesConfig, null, 2));

console.log('Seed JSON files generated successfully in shared/seed!');
